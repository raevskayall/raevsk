// Проверка авторизации перед загрузкой содержимого
const protectedPaths = ['/clients.html', '/realtors.html', '/properties.html', '/transactions.html'];

if (protectedPaths.includes(window.location.pathname)) {
    fetch('/api/profile', { credentials: 'include' }) // Включаем куки
        .then((response) => {
            if (!response.ok) {
                window.location.href = '/login.html?error=not_authorized'; // Перенаправляем на страницу входа
                return;
            }
            return response.json();
        })
        .then((data) => {
            const userInfoElement = document.getElementById('userInfo');
            if (userInfoElement) {
                userInfoElement.innerHTML = `
                    <p>Пользователь: ${data.username}</p>
                    <p>Роль: ${data.role}</p>
                `;
            }
        })
        .catch((error) => {
            console.error('Ошибка:', error);
            alert('Ошибка загрузки данных профиля. Пожалуйста, перезагрузите страницу.');
        });
}

// Логика для выхода
document.getElementById('logout')?.addEventListener('click', async () => {
    await fetch('/api/logout', { method: 'POST', credentials: 'include' }); // Включаем куки
    window.location.href = '/login.html'; // Перенаправление на страницу входа
});

// Логика регистрации
document.getElementById('registerForm')?.addEventListener('submit', async function(event) {
    event.preventDefault();
    const formData = new FormData(this);
    const data = Object.fromEntries(formData);
    const response = await fetch('/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
    });
    if (response.ok) {
        alert('Регистрация успешна! Теперь вы можете войти.');
        window.location.href = '/login.html'; // Перенаправление на страницу входа
    } else {
        const error = await response.json();
        alert(`Ошибка регистрации: ${error.error}`);
    }
});

// Логика входа
document.getElementById('loginForm')?.addEventListener('submit', async function(event) {
    event.preventDefault();
    const formData = new FormData(this);
    const data = Object.fromEntries(formData);
    const response = await fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
    });
    if (response.ok) {
        window.location.href = '/index.html'; 
    } else {
        alert('Ошибка входа: Неверные учетные данные');
    }
});

// Логика добавления клиента
document.getElementById('clientForm')?.addEventListener('submit', async function(event) {
    event.preventDefault();
    const formData = new FormData(this);
    const data = Object.fromEntries(formData);
    const response = await fetch('/clients', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
        credentials: 'include' // Включаем куки
    });
    if (response.ok) {
        alert('Клиент добавлен!');
        loadClients(); // Обновляем список клиентов
    } else {
        alert('Ошибка при добавлении клиента');
    }
});

// Логика добавления риэлтора
document.getElementById('realtorForm')?.addEventListener('submit', async function(event) {
    event.preventDefault();
    const formData = new FormData(this);
    const data = Object.fromEntries(formData);
    const response = await fetch('/realtors', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
        credentials: 'include' // Включаем куки
    });
    if (response.ok) {
        alert('Риэлтор добавлен!');
        loadRealtors(); // Обновляем список риэлторов
    } else {
        alert('Ошибка при добавлении риэлтора');
    }
});

// Логика добавления объекта недвижимости
document.getElementById('propertyForm')?.addEventListener('submit', async function(event) {
    event.preventDefault();
    const formData = new FormData(this);
    const data = Object.fromEntries(formData);
    const response = await fetch('/properties', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
        credentials: 'include' // Включаем куки
    });
    if (response.ok) {
        alert('Объект недвижимости добавлен!');
        loadProperties(); // Обновляем список объектов недвижимости
    } else {
        alert('Ошибка при добавлении объекта недвижимости');
    }
});

// Логика добавления сделки
document.getElementById('transactionForm')?.addEventListener('submit', async function(event) {
    event.preventDefault();
    const formData = new FormData(this);
    const data = Object.fromEntries(formData);
    const response = await fetch('/transactions', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
        credentials: 'include' // Включаем куки
    });
    if (response.ok) {
        alert('Сделка добавлена!');
        loadTransactions(); // Обновляем список сделок
    } else {
        alert('Ошибка при добавлении сделки');
    }
});

// Функция для загрузки клиентов
async function loadClients() {
    const response = await fetch('/clients', { credentials: 'include' }); // Включаем куки
    const clients = await response.json();
    const clientList = document.getElementById('clientList');
    clientList.innerHTML = '';
    clients.forEach(client => {
        const li = document.createElement('li');
        li.textContent = `${client.first_name} ${client.last_name} - ${client.email} - ${client.phone}`;
        clientList.appendChild(li);
    });
}

// Функция для загрузки риэлторов
async function loadRealtors() {
    const response = await fetch('/realtors', { credentials: 'include' }); // Включаем куки
    const realtors = await response.json();
    const realtorList = document.getElementById('realtorList');
    realtorList.innerHTML = '';
    realtors.forEach(realtor => {
        const li = document.createElement('li');
        li.textContent = `${realtor.name} - ${realtor.contact}`;
        realtorList.appendChild(li);
    });
}

// Функция для загрузки объектов недвижимости
async function loadProperties() {
    const response = await fetch('/properties', { credentials: 'include' }); // Включаем куки
    const properties = await response.json();
    const propertyList = document.getElementById('propertyList');
    propertyList.innerHTML = '';
    properties.forEach(property => {
        const li = document.createElement('li');
        li.textContent = `${property.address} - ${property.price}`;
        propertyList.appendChild(li);
    });
}

// Функция для загрузки сделок
async function loadTransactions() {
    const response = await fetch('/transactions', { credentials: 'include' }); // Включаем куки
    const transactions = await response.json();
    const transactionList = document.getElementById('transactionList');
    transactionList.innerHTML = '';
    transactions.forEach(transaction => {
        const li = document.createElement('li');
        li.textContent = `Сделка: ${transaction.details} - ${transaction.date}`;
        transactionList.appendChild(li);
    });
}

// Загружаем клиентов, риэлторов, объекты недвижимости и сделки при загрузке соответствующих страниц
if (window.location.pathname === '/clients.html') {
    loadClients();
} else if (window.location.pathname === '/realtors.html') {
    loadRealtors();
} else if (window.location.pathname === '/properties.html') {
    loadProperties();
} else if (window.location.pathname === '/transactions.html') {
    loadTransactions();
}