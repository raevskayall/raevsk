--
-- PostgreSQL database cluster dump
--

-- Started on 2025-04-22 05:49:37

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE admin;
ALTER ROLE admin WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS;
CREATE ROLE client;
ALTER ROLE client WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS;
CREATE ROLE employees;
ALTER ROLE employees WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS;
CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS;

--
-- User Configurations
--








--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

-- Started on 2025-04-22 05:49:38

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

-- Completed on 2025-04-22 05:49:38

--
-- PostgreSQL database dump complete
--

--
-- Database "autoservice" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

-- Started on 2025-04-22 05:49:38

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 4869 (class 1262 OID 25162)
-- Name: autoservice; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE autoservice WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'ru-RU';


ALTER DATABASE autoservice OWNER TO postgres;

\connect autoservice

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 226 (class 1259 OID 25205)
-- Name: appointments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.appointments (
    appointmentid integer NOT NULL,
    datetime timestamp without time zone NOT NULL,
    clientid integer,
    carid integer,
    serviceid integer,
    employeeid integer
);


ALTER TABLE public.appointments OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 25204)
-- Name: appointments_appointmentid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.appointments_appointmentid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.appointments_appointmentid_seq OWNER TO postgres;

--
-- TOC entry 4871 (class 0 OID 0)
-- Dependencies: 225
-- Name: appointments_appointmentid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.appointments_appointmentid_seq OWNED BY public.appointments.appointmentid;


--
-- TOC entry 220 (class 1259 OID 25173)
-- Name: cars; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cars (
    carid integer NOT NULL,
    brand character varying(50) NOT NULL,
    model character varying(50) NOT NULL,
    year integer NOT NULL,
    vin character varying(17) NOT NULL,
    clientid integer
);


ALTER TABLE public.cars OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 25172)
-- Name: cars_carid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cars_carid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cars_carid_seq OWNER TO postgres;

--
-- TOC entry 4872 (class 0 OID 0)
-- Dependencies: 219
-- Name: cars_carid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cars_carid_seq OWNED BY public.cars.carid;


--
-- TOC entry 218 (class 1259 OID 25164)
-- Name: clients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clients (
    clientid integer NOT NULL,
    fullname character varying(100) NOT NULL,
    phone character varying(15) NOT NULL,
    email character varying(100) NOT NULL,
    address character varying(255)
);


ALTER TABLE public.clients OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 25163)
-- Name: clients_clientid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.clients_clientid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.clients_clientid_seq OWNER TO postgres;

--
-- TOC entry 4873 (class 0 OID 0)
-- Dependencies: 217
-- Name: clients_clientid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.clients_clientid_seq OWNED BY public.clients.clientid;


--
-- TOC entry 224 (class 1259 OID 25196)
-- Name: employees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employees (
    employeeid integer NOT NULL,
    fullname character varying(100) NOT NULL,
    "position" character varying(50),
    phone character varying(15) NOT NULL,
    email character varying(100) NOT NULL,
    password character varying(100),
    role character varying(50) DEFAULT 'employee'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.employees OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 25195)
-- Name: employees_employeeid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employees_employeeid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.employees_employeeid_seq OWNER TO postgres;

--
-- TOC entry 4874 (class 0 OID 0)
-- Dependencies: 223
-- Name: employees_employeeid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employees_employeeid_seq OWNED BY public.employees.employeeid;


--
-- TOC entry 228 (class 1259 OID 25232)
-- Name: invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoices (
    invoiceid integer NOT NULL,
    appointmentid integer,
    amount numeric(10,2) NOT NULL,
    createdat timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(10) NOT NULL,
    CONSTRAINT invoices_status_check CHECK (((status)::text = ANY ((ARRAY['paid'::character varying, 'unpaid'::character varying])::text[])))
);


ALTER TABLE public.invoices OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 25231)
-- Name: invoices_invoiceid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.invoices_invoiceid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.invoices_invoiceid_seq OWNER TO postgres;

--
-- TOC entry 4875 (class 0 OID 0)
-- Dependencies: 227
-- Name: invoices_invoiceid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.invoices_invoiceid_seq OWNED BY public.invoices.invoiceid;


--
-- TOC entry 222 (class 1259 OID 25187)
-- Name: services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.services (
    serviceid integer NOT NULL,
    servicename character varying(100) NOT NULL,
    description text,
    price numeric(10,2) NOT NULL
);


ALTER TABLE public.services OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 25186)
-- Name: services_serviceid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.services_serviceid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.services_serviceid_seq OWNER TO postgres;

--
-- TOC entry 4876 (class 0 OID 0)
-- Dependencies: 221
-- Name: services_serviceid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.services_serviceid_seq OWNED BY public.services.serviceid;


--
-- TOC entry 4672 (class 2604 OID 25208)
-- Name: appointments appointmentid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments ALTER COLUMN appointmentid SET DEFAULT nextval('public.appointments_appointmentid_seq'::regclass);


--
-- TOC entry 4667 (class 2604 OID 25176)
-- Name: cars carid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cars ALTER COLUMN carid SET DEFAULT nextval('public.cars_carid_seq'::regclass);


--
-- TOC entry 4666 (class 2604 OID 25167)
-- Name: clients clientid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients ALTER COLUMN clientid SET DEFAULT nextval('public.clients_clientid_seq'::regclass);


--
-- TOC entry 4669 (class 2604 OID 25199)
-- Name: employees employeeid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees ALTER COLUMN employeeid SET DEFAULT nextval('public.employees_employeeid_seq'::regclass);


--
-- TOC entry 4673 (class 2604 OID 25235)
-- Name: invoices invoiceid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices ALTER COLUMN invoiceid SET DEFAULT nextval('public.invoices_invoiceid_seq'::regclass);


--
-- TOC entry 4668 (class 2604 OID 25190)
-- Name: services serviceid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services ALTER COLUMN serviceid SET DEFAULT nextval('public.services_serviceid_seq'::regclass);


--
-- TOC entry 4861 (class 0 OID 25205)
-- Dependencies: 226
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.appointments (appointmentid, datetime, clientid, carid, serviceid, employeeid) FROM stdin;
\.


--
-- TOC entry 4855 (class 0 OID 25173)
-- Dependencies: 220
-- Data for Name: cars; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cars (carid, brand, model, year, vin, clientid) FROM stdin;
2	Honda	Civic	2018	2HGFC2F56LH567890	2
4	BMW	X5	2020	5UXCR6C0XL1234567	4
5	Audi	A4	2019	WAUZZZ8K9LA123456	5
1	Toyota	Corolla	2016	JTDKARFU9E1543563	1
\.


--
-- TOC entry 4853 (class 0 OID 25164)
-- Dependencies: 218
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clients (clientid, fullname, phone, email, address) FROM stdin;
2	Jane Smith	+79107654321	jane.smith@example.com	456 Elm St, St. Petersburg
3	Alice Johnson	+79109876543	alice.johnson@example.com	789 Oak St, Kazan
4	Bob Brown	+79101112233	bob.brown@example.com	321 Pine St, Novosibirsk
1	Гена Цидармян	+79101234545	gena.cidarmyan@example.com	123 Main St, Moscow
5	Charlie Davis	+79104445566	charlie.davis@example.com	654 Maple St, Yekaterinburg
\.


--
-- TOC entry 4859 (class 0 OID 25196)
-- Dependencies: 224
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employees (employeeid, fullname, "position", phone, email, password, role, is_active) FROM stdin;
6	Артур Бузукин	Администратор	+79990000777	admin@gmail.com	$2b$10$vEcVhc4PlPfJkkhJgJygc.gGNmRG42SWRYO0u7vBxoNrjRc10CB5C	admin	t
9	Александр Алес Алексов	\N	+79995553535	user@gmail.com	$2b$10$vM1xnVweZWr521vuUU/uIeb.hI99NarHCDJC7LSrUxtDlR/ycNbMC	mechanic	t
\.


--
-- TOC entry 4863 (class 0 OID 25232)
-- Dependencies: 228
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoices (invoiceid, appointmentid, amount, createdat, status) FROM stdin;
\.


--
-- TOC entry 4857 (class 0 OID 25187)
-- Dependencies: 222
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.services (serviceid, servicename, description, price) FROM stdin;
3	Ротация шин	Вращение шин для обеспечения равномерного износа	1500.00
5	Диагностика двигателя	Диагностика двигателя	2500.00
4	Замена батареи	Замена батареи	3000.00
\.


--
-- TOC entry 4877 (class 0 OID 0)
-- Dependencies: 225
-- Name: appointments_appointmentid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.appointments_appointmentid_seq', 5, true);


--
-- TOC entry 4878 (class 0 OID 0)
-- Dependencies: 219
-- Name: cars_carid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cars_carid_seq', 5, true);


--
-- TOC entry 4879 (class 0 OID 0)
-- Dependencies: 217
-- Name: clients_clientid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.clients_clientid_seq', 6, true);


--
-- TOC entry 4880 (class 0 OID 0)
-- Dependencies: 223
-- Name: employees_employeeid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employees_employeeid_seq', 9, true);


--
-- TOC entry 4881 (class 0 OID 0)
-- Dependencies: 227
-- Name: invoices_invoiceid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.invoices_invoiceid_seq', 5, true);


--
-- TOC entry 4882 (class 0 OID 0)
-- Dependencies: 221
-- Name: services_serviceid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.services_serviceid_seq', 7, true);


--
-- TOC entry 4693 (class 2606 OID 25210)
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (appointmentid);


--
-- TOC entry 4682 (class 2606 OID 25178)
-- Name: cars cars_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cars
    ADD CONSTRAINT cars_pkey PRIMARY KEY (carid);


--
-- TOC entry 4684 (class 2606 OID 25180)
-- Name: cars cars_vin_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cars
    ADD CONSTRAINT cars_vin_key UNIQUE (vin);


--
-- TOC entry 4677 (class 2606 OID 25171)
-- Name: clients clients_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_email_key UNIQUE (email);


--
-- TOC entry 4679 (class 2606 OID 25169)
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (clientid);


--
-- TOC entry 4689 (class 2606 OID 25203)
-- Name: employees employees_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_email_key UNIQUE (email);


--
-- TOC entry 4691 (class 2606 OID 25201)
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (employeeid);


--
-- TOC entry 4700 (class 2606 OID 25239)
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (invoiceid);


--
-- TOC entry 4687 (class 2606 OID 25194)
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (serviceid);


--
-- TOC entry 4694 (class 1259 OID 25249)
-- Name: idx_appointments_car; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_appointments_car ON public.appointments USING btree (carid);


--
-- TOC entry 4695 (class 1259 OID 25250)
-- Name: idx_appointments_client; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_appointments_client ON public.appointments USING btree (clientid);


--
-- TOC entry 4696 (class 1259 OID 25247)
-- Name: idx_appointments_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_appointments_employee ON public.appointments USING btree (employeeid);


--
-- TOC entry 4697 (class 1259 OID 25248)
-- Name: idx_appointments_service; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_appointments_service ON public.appointments USING btree (serviceid);


--
-- TOC entry 4685 (class 1259 OID 25246)
-- Name: idx_cars_client; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cars_client ON public.cars USING btree (clientid);


--
-- TOC entry 4680 (class 1259 OID 25245)
-- Name: idx_clients_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_clients_email ON public.clients USING btree (email);


--
-- TOC entry 4698 (class 1259 OID 25251)
-- Name: idx_invoices_appointment; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_invoices_appointment ON public.invoices USING btree (appointmentid);


--
-- TOC entry 4702 (class 2606 OID 25216)
-- Name: appointments appointments_carid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_carid_fkey FOREIGN KEY (carid) REFERENCES public.cars(carid) ON DELETE CASCADE;


--
-- TOC entry 4703 (class 2606 OID 25211)
-- Name: appointments appointments_clientid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_clientid_fkey FOREIGN KEY (clientid) REFERENCES public.clients(clientid) ON DELETE CASCADE;


--
-- TOC entry 4704 (class 2606 OID 25226)
-- Name: appointments appointments_employeeid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_employeeid_fkey FOREIGN KEY (employeeid) REFERENCES public.employees(employeeid) ON DELETE CASCADE;


--
-- TOC entry 4705 (class 2606 OID 25221)
-- Name: appointments appointments_serviceid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_serviceid_fkey FOREIGN KEY (serviceid) REFERENCES public.services(serviceid) ON DELETE CASCADE;


--
-- TOC entry 4701 (class 2606 OID 25181)
-- Name: cars cars_clientid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cars
    ADD CONSTRAINT cars_clientid_fkey FOREIGN KEY (clientid) REFERENCES public.clients(clientid) ON DELETE CASCADE;


--
-- TOC entry 4706 (class 2606 OID 25240)
-- Name: invoices invoices_appointmentid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_appointmentid_fkey FOREIGN KEY (appointmentid) REFERENCES public.appointments(appointmentid) ON DELETE CASCADE;


--
-- TOC entry 4870 (class 0 OID 0)
-- Dependencies: 4869
-- Name: DATABASE autoservice; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON DATABASE autoservice TO admin;


-- Completed on 2025-04-22 05:49:38

--
-- PostgreSQL database dump complete
--

--
-- Database "car_dealership" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

-- Started on 2025-04-22 05:49:38

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 5011 (class 1262 OID 24924)
-- Name: car_dealership; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE car_dealership WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'ru-RU';


ALTER DATABASE car_dealership OWNER TO postgres;

\connect car_dealership

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 248 (class 1255 OID 25913)
-- Name: authenticate_user(character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.authenticate_user(p_username character varying, p_password character varying) RETURNS TABLE(user_id integer, full_name character varying, email character varying, roles text[])
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        u.user_id,
        u.full_name,
        u.email,
        ARRAY_AGG(r.role_name)::TEXT[] AS roles
    FROM system_users u
    JOIN user_role_mapping m ON u.user_id = m.user_id
    JOIN user_roles r ON m.role_id = r.role_id
    WHERE u.username = p_username
    AND u.password_hash = crypt(p_password, u.password_hash)
    AND u.is_active = TRUE
    GROUP BY u.user_id, u.full_name, u.email;
END;
$$;


ALTER FUNCTION public.authenticate_user(p_username character varying, p_password character varying) OWNER TO postgres;

--
-- TOC entry 246 (class 1255 OID 25867)
-- Name: check_car_inventory(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.check_car_inventory() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM inventory WHERE car_id = NEW.car_id) THEN
        RAISE EXCEPTION 'Автомобиль отсутствует в инвентаре';
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.check_car_inventory() OWNER TO postgres;

--
-- TOC entry 245 (class 1255 OID 25865)
-- Name: update_car_status_after_sale(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_car_status_after_sale() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE cars SET status = 'sold' WHERE car_id = NEW.car_id;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_car_status_after_sale() OWNER TO postgres;

--
-- TOC entry 247 (class 1255 OID 25911)
-- Name: update_last_login(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_last_login() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.last_login = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_last_login() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 218 (class 1259 OID 25661)
-- Name: car_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.car_categories (
    category_id integer NOT NULL,
    category_name character varying(50) NOT NULL
);


ALTER TABLE public.car_categories OWNER TO postgres;

--
-- TOC entry 222 (class 1259 OID 25675)
-- Name: cars; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cars (
    car_id integer NOT NULL,
    vin character varying(17) NOT NULL,
    brand character varying(50) NOT NULL,
    model character varying(50) NOT NULL,
    year integer NOT NULL,
    color character varying(30) NOT NULL,
    price numeric(10,2) NOT NULL,
    mileage integer DEFAULT 0,
    status character varying(10) DEFAULT 'available'::character varying NOT NULL,
    technical_specs text,
    manufacturer_id integer,
    category_id integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT cars_mileage_check CHECK ((mileage >= 0)),
    CONSTRAINT cars_price_check CHECK ((price > (0)::numeric)),
    CONSTRAINT cars_status_check CHECK (((status)::text = ANY ((ARRAY['available'::character varying, 'sold'::character varying, 'reserved'::character varying])::text[]))),
    CONSTRAINT cars_year_check CHECK (((year > 1900) AND ((year)::numeric <= (EXTRACT(year FROM CURRENT_DATE) + (1)::numeric))))
);


ALTER TABLE public.cars OWNER TO postgres;

--
-- TOC entry 220 (class 1259 OID 25668)
-- Name: manufacturers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.manufacturers (
    manufacturer_id integer NOT NULL,
    name character varying(100) NOT NULL,
    country character varying(50) NOT NULL
);


ALTER TABLE public.manufacturers OWNER TO postgres;

--
-- TOC entry 238 (class 1259 OID 25855)
-- Name: available_cars; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.available_cars AS
 SELECT c.car_id,
    c.vin,
    c.brand,
    c.model,
    c.year,
    c.color,
    c.price,
    m.name AS manufacturer,
    cat.category_name
   FROM ((public.cars c
     JOIN public.manufacturers m ON ((c.manufacturer_id = m.manufacturer_id)))
     JOIN public.car_categories cat ON ((c.category_id = cat.category_id)))
  WHERE ((c.status)::text = 'available'::text);


ALTER VIEW public.available_cars OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 25660)
-- Name: car_categories_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.car_categories_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.car_categories_category_id_seq OWNER TO postgres;

--
-- TOC entry 5012 (class 0 OID 0)
-- Dependencies: 217
-- Name: car_categories_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.car_categories_category_id_seq OWNED BY public.car_categories.category_id;


--
-- TOC entry 237 (class 1259 OID 25840)
-- Name: car_promotions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.car_promotions (
    car_id integer NOT NULL,
    promotion_id integer NOT NULL
);


ALTER TABLE public.car_promotions OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 25674)
-- Name: cars_car_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cars_car_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cars_car_id_seq OWNER TO postgres;

--
-- TOC entry 5013 (class 0 OID 0)
-- Dependencies: 221
-- Name: cars_car_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cars_car_id_seq OWNED BY public.cars.car_id;


--
-- TOC entry 224 (class 1259 OID 25706)
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    customer_id integer NOT NULL,
    full_name character varying(100) NOT NULL,
    phone character varying(15) NOT NULL,
    email character varying(100) NOT NULL,
    address character varying(255),
    birth_date date,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT customers_birth_date_check CHECK (((birth_date > '1900-01-01'::date) AND (birth_date <= CURRENT_DATE)))
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 25705)
-- Name: customers_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customers_customer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customers_customer_id_seq OWNER TO postgres;

--
-- TOC entry 5014 (class 0 OID 0)
-- Dependencies: 223
-- Name: customers_customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customers_customer_id_seq OWNED BY public.customers.customer_id;


--
-- TOC entry 226 (class 1259 OID 25719)
-- Name: employees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employees (
    employee_id integer NOT NULL,
    full_name character varying(100) NOT NULL,
    "position" character varying(50) NOT NULL,
    phone character varying(15) NOT NULL,
    email character varying(100) NOT NULL,
    hire_date date NOT NULL,
    salary numeric(10,2) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT employees_hire_date_check CHECK ((hire_date <= CURRENT_DATE)),
    CONSTRAINT employees_salary_check CHECK ((salary > (0)::numeric))
);


ALTER TABLE public.employees OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 25718)
-- Name: employees_employee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employees_employee_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.employees_employee_id_seq OWNER TO postgres;

--
-- TOC entry 5015 (class 0 OID 0)
-- Dependencies: 225
-- Name: employees_employee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employees_employee_id_seq OWNED BY public.employees.employee_id;


--
-- TOC entry 234 (class 1259 OID 25810)
-- Name: inventory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory (
    inventory_id integer NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    location character varying(100),
    last_update timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    car_id integer NOT NULL,
    CONSTRAINT inventory_quantity_check CHECK ((quantity >= 0))
);


ALTER TABLE public.inventory OWNER TO postgres;

--
-- TOC entry 233 (class 1259 OID 25809)
-- Name: inventory_inventory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inventory_inventory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inventory_inventory_id_seq OWNER TO postgres;

--
-- TOC entry 5016 (class 0 OID 0)
-- Dependencies: 233
-- Name: inventory_inventory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inventory_inventory_id_seq OWNED BY public.inventory.inventory_id;


--
-- TOC entry 219 (class 1259 OID 25667)
-- Name: manufacturers_manufacturer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.manufacturers_manufacturer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.manufacturers_manufacturer_id_seq OWNER TO postgres;

--
-- TOC entry 5017 (class 0 OID 0)
-- Dependencies: 219
-- Name: manufacturers_manufacturer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.manufacturers_manufacturer_id_seq OWNED BY public.manufacturers.manufacturer_id;


--
-- TOC entry 236 (class 1259 OID 25827)
-- Name: promotions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.promotions (
    promotion_id integer NOT NULL,
    title character varying(100) NOT NULL,
    description text,
    discount numeric(5,2),
    start_date date NOT NULL,
    end_date date NOT NULL,
    status character varying(10) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT promotions_check CHECK ((end_date >= start_date)),
    CONSTRAINT promotions_discount_check CHECK (((discount > (0)::numeric) AND (discount <= (100)::numeric))),
    CONSTRAINT promotions_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying])::text[])))
);


ALTER TABLE public.promotions OWNER TO postgres;

--
-- TOC entry 235 (class 1259 OID 25826)
-- Name: promotions_promotion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.promotions_promotion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.promotions_promotion_id_seq OWNER TO postgres;

--
-- TOC entry 5018 (class 0 OID 0)
-- Dependencies: 235
-- Name: promotions_promotion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.promotions_promotion_id_seq OWNED BY public.promotions.promotion_id;


--
-- TOC entry 232 (class 1259 OID 25786)
-- Name: reviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reviews (
    review_id integer NOT NULL,
    review_date date DEFAULT CURRENT_DATE NOT NULL,
    rating smallint NOT NULL,
    comment text,
    customer_id integer NOT NULL,
    car_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT reviews_rating_check CHECK (((rating >= 1) AND (rating <= 5)))
);


ALTER TABLE public.reviews OWNER TO postgres;

--
-- TOC entry 231 (class 1259 OID 25785)
-- Name: reviews_review_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reviews_review_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reviews_review_id_seq OWNER TO postgres;

--
-- TOC entry 5019 (class 0 OID 0)
-- Dependencies: 231
-- Name: reviews_review_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reviews_review_id_seq OWNED BY public.reviews.review_id;


--
-- TOC entry 228 (class 1259 OID 25731)
-- Name: sales; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales (
    sale_id integer NOT NULL,
    sale_date date DEFAULT CURRENT_DATE NOT NULL,
    sale_price numeric(10,2) NOT NULL,
    payment_method character varying(10) NOT NULL,
    car_id integer NOT NULL,
    customer_id integer NOT NULL,
    employee_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT sales_payment_method_check CHECK (((payment_method)::text = ANY ((ARRAY['cash'::character varying, 'credit'::character varying, 'lease'::character varying])::text[]))),
    CONSTRAINT sales_sale_price_check CHECK ((sale_price > (0)::numeric))
);


ALTER TABLE public.sales OWNER TO postgres;

--
-- TOC entry 239 (class 1259 OID 25860)
-- Name: sales_report; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.sales_report AS
 SELECT e.full_name AS employee,
    count(s.sale_id) AS sales_count,
    sum(s.sale_price) AS total_sales,
    avg(s.sale_price) AS average_sale,
    min(s.sale_date) AS first_sale,
    max(s.sale_date) AS last_sale
   FROM (public.sales s
     JOIN public.employees e ON ((s.employee_id = e.employee_id)))
  GROUP BY e.employee_id, e.full_name
  ORDER BY (sum(s.sale_price)) DESC;


ALTER VIEW public.sales_report OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 25730)
-- Name: sales_sale_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_sale_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_sale_id_seq OWNER TO postgres;

--
-- TOC entry 5020 (class 0 OID 0)
-- Dependencies: 227
-- Name: sales_sale_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_sale_id_seq OWNED BY public.sales.sale_id;


--
-- TOC entry 230 (class 1259 OID 25761)
-- Name: service_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_records (
    service_id integer NOT NULL,
    service_date date DEFAULT CURRENT_DATE NOT NULL,
    service_type character varying(20) NOT NULL,
    description text,
    cost numeric(10,2) NOT NULL,
    car_id integer NOT NULL,
    employee_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT service_records_cost_check CHECK ((cost >= (0)::numeric)),
    CONSTRAINT service_records_service_type_check CHECK (((service_type)::text = ANY ((ARRAY['maintenance'::character varying, 'repair'::character varying, 'inspection'::character varying])::text[])))
);


ALTER TABLE public.service_records OWNER TO postgres;

--
-- TOC entry 229 (class 1259 OID 25760)
-- Name: service_records_service_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.service_records_service_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.service_records_service_id_seq OWNER TO postgres;

--
-- TOC entry 5021 (class 0 OID 0)
-- Dependencies: 229
-- Name: service_records_service_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.service_records_service_id_seq OWNED BY public.service_records.service_id;


--
-- TOC entry 241 (class 1259 OID 25870)
-- Name: system_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_users (
    user_id integer NOT NULL,
    username character varying(50) NOT NULL,
    password_hash character varying(255) NOT NULL,
    full_name character varying(100) NOT NULL,
    email character varying(100) NOT NULL,
    is_active boolean DEFAULT true,
    last_login timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.system_users OWNER TO postgres;

--
-- TOC entry 240 (class 1259 OID 25869)
-- Name: system_users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.system_users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_users_user_id_seq OWNER TO postgres;

--
-- TOC entry 5022 (class 0 OID 0)
-- Dependencies: 240
-- Name: system_users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.system_users_user_id_seq OWNED BY public.system_users.user_id;


--
-- TOC entry 244 (class 1259 OID 25896)
-- Name: user_role_mapping; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_role_mapping (
    user_id integer NOT NULL,
    role_id integer NOT NULL
);


ALTER TABLE public.user_role_mapping OWNER TO postgres;

--
-- TOC entry 243 (class 1259 OID 25886)
-- Name: user_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_roles (
    role_id integer NOT NULL,
    role_name character varying(50) NOT NULL,
    description text
);


ALTER TABLE public.user_roles OWNER TO postgres;

--
-- TOC entry 242 (class 1259 OID 25885)
-- Name: user_roles_role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_roles_role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_roles_role_id_seq OWNER TO postgres;

--
-- TOC entry 5023 (class 0 OID 0)
-- Dependencies: 242
-- Name: user_roles_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_roles_role_id_seq OWNED BY public.user_roles.role_id;


--
-- TOC entry 4716 (class 2604 OID 25664)
-- Name: car_categories category_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.car_categories ALTER COLUMN category_id SET DEFAULT nextval('public.car_categories_category_id_seq'::regclass);


--
-- TOC entry 4718 (class 2604 OID 25678)
-- Name: cars car_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cars ALTER COLUMN car_id SET DEFAULT nextval('public.cars_car_id_seq'::regclass);


--
-- TOC entry 4722 (class 2604 OID 25709)
-- Name: customers customer_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers ALTER COLUMN customer_id SET DEFAULT nextval('public.customers_customer_id_seq'::regclass);


--
-- TOC entry 4724 (class 2604 OID 25722)
-- Name: employees employee_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees ALTER COLUMN employee_id SET DEFAULT nextval('public.employees_employee_id_seq'::regclass);


--
-- TOC entry 4735 (class 2604 OID 25813)
-- Name: inventory inventory_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory ALTER COLUMN inventory_id SET DEFAULT nextval('public.inventory_inventory_id_seq'::regclass);


--
-- TOC entry 4717 (class 2604 OID 25671)
-- Name: manufacturers manufacturer_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manufacturers ALTER COLUMN manufacturer_id SET DEFAULT nextval('public.manufacturers_manufacturer_id_seq'::regclass);


--
-- TOC entry 4738 (class 2604 OID 25830)
-- Name: promotions promotion_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promotions ALTER COLUMN promotion_id SET DEFAULT nextval('public.promotions_promotion_id_seq'::regclass);


--
-- TOC entry 4732 (class 2604 OID 25789)
-- Name: reviews review_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews ALTER COLUMN review_id SET DEFAULT nextval('public.reviews_review_id_seq'::regclass);


--
-- TOC entry 4726 (class 2604 OID 25734)
-- Name: sales sale_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales ALTER COLUMN sale_id SET DEFAULT nextval('public.sales_sale_id_seq'::regclass);


--
-- TOC entry 4729 (class 2604 OID 25764)
-- Name: service_records service_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_records ALTER COLUMN service_id SET DEFAULT nextval('public.service_records_service_id_seq'::regclass);


--
-- TOC entry 4741 (class 2604 OID 25873)
-- Name: system_users user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_users ALTER COLUMN user_id SET DEFAULT nextval('public.system_users_user_id_seq'::regclass);


--
-- TOC entry 4745 (class 2604 OID 25889)
-- Name: user_roles role_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles ALTER COLUMN role_id SET DEFAULT nextval('public.user_roles_role_id_seq'::regclass);


--
-- TOC entry 4981 (class 0 OID 25661)
-- Dependencies: 218
-- Data for Name: car_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.car_categories (category_id, category_name) FROM stdin;
1	Sedan
2	SUV
3	Hatchback
4	Coupe
5	Minivan
6	Pickup
7	Sports Car
8	Electric Vehicle
9	Luxury
10	Commercial
\.


--
-- TOC entry 5000 (class 0 OID 25840)
-- Dependencies: 237
-- Data for Name: car_promotions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.car_promotions (car_id, promotion_id) FROM stdin;
\.


--
-- TOC entry 4985 (class 0 OID 25675)
-- Dependencies: 222
-- Data for Name: cars; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cars (car_id, vin, brand, model, year, color, price, mileage, status, technical_specs, manufacturer_id, category_id, created_at) FROM stdin;
1	XTA21099765432101	Lada	Vesta	2023	Black	1200000.00	0	available	1.6L engine, 106 HP, automatic transmission	9	1	2025-04-22 04:44:15.156507+03
2	JTEBU5JR9E5151461	Toyota	Camry	2022	White	2500000.00	15000	available	2.5L engine, 181 HP, hybrid, leather interior	1	1	2025-04-22 04:44:15.156507+03
3	WVWZZZAUZJW123456	Volkswagen	Tiguan	2021	Silver	2200000.00	35000	available	2.0L TSI, 190 HP, 4MOTION, panoramic roof	2	2	2025-04-22 04:44:15.156507+03
4	3FA6P0H96HR123456	Ford	Focus	2020	Blue	1500000.00	45000	sold	1.5L EcoBoost, 150 HP, SYNC 3 system	3	3	2025-04-22 04:44:15.156507+03
5	WBA8E9C58JA123456	BMW	X5	2022	Black	6500000.00	10000	available	3.0L diesel, 265 HP, xDrive, M Sport package	4	2	2025-04-22 04:44:15.156507+03
6	WDDUG8FB3HA123456	Mercedes	E-Class	2021	Gray	5800000.00	20000	available	E 200, 2.0L, 197 HP, AMG Line	5	1	2025-04-22 04:44:15.156507+03
7	WAUZZZF51KA123456	Audi	A6	2022	Dark Blue	5200000.00	5000	reserved	3.0L TDI, 231 HP, quattro, virtual cockpit	6	1	2025-04-22 04:44:15.156507+03
8	KMHSU81CTHU123456	Hyundai	Tucson	2021	Red	2300000.00	25000	available	1.6L turbo, 177 HP, SmartSense package	7	2	2025-04-22 04:44:15.156507+03
9	KNAKU8112K5123456	Kia	Rio	2022	White	1300000.00	10000	available	1.6L, 123 HP, 6-speed automatic	8	1	2025-04-22 04:44:15.156507+03
10	VF1RFA00565432101	Renault	Duster	2021	Orange	1400000.00	30000	available	1.6L, 114 HP, 4WD, off-road package	10	2	2025-04-22 04:44:15.156507+03
\.


--
-- TOC entry 4987 (class 0 OID 25706)
-- Dependencies: 224
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (customer_id, full_name, phone, email, address, birth_date, created_at) FROM stdin;
1	Иванов Иван Иванович	+79161234567	ivanov@example.com	г. Москва, ул. Ленина, д. 1	1985-05-20	2025-04-22 04:44:21.016792+03
2	Петров Петр Петрович	+79167654321	petrov@example.com	г. Санкт-Петербург, Невский пр., д. 10	1990-11-15	2025-04-22 04:44:21.016792+03
3	Сидорова Анна Сергеевна	+79165554433	sidorova@example.com	г. Екатеринбург, ул. Малышева, д. 5	1988-03-10	2025-04-22 04:44:21.016792+03
4	Кузнецов Дмитрий Алексеевич	+79168889900	kuznetsov@example.com	г. Новосибирск, ул. Кирова, д. 15	1979-07-25	2025-04-22 04:44:21.016792+03
5	Смирнова Елена Викторовна	+79162223344	smirnova@example.com	г. Казань, ул. Баумана, д. 20	1992-09-30	2025-04-22 04:44:21.016792+03
6	Федоров Алексей Николаевич	+79163334455	fedorov@example.com	г. Сочи, ул. Навагинская, д. 7	1983-12-05	2025-04-22 04:44:21.016792+03
7	Николаева Ольга Дмитриевна	+79164445566	nikolaeva@example.com	г. Владивосток, ул. Светланская, д. 25	1995-02-18	2025-04-22 04:44:21.016792+03
8	Волков Сергей Иванович	+79167778899	volkov@example.com	г. Калининград, Ленинский пр., д. 30	1975-08-12	2025-04-22 04:44:21.016792+03
9	Зайцева Марина Петровна	+79161112233	zaitseva@example.com	г. Красноярск, ул. Карла Маркса, д. 40	1980-04-22	2025-04-22 04:44:21.016792+03
10	Белов Андрей Сергеевич	+79169998877	belov@example.com	г. Уфа, ул. Ленина, д. 50	1991-10-08	2025-04-22 04:44:21.016792+03
\.


--
-- TOC entry 4989 (class 0 OID 25719)
-- Dependencies: 226
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employees (employee_id, full_name, "position", phone, email, hire_date, salary, created_at) FROM stdin;
1	Соколов Алексей Владимирович	Менеджер по продажам	+79160001122	sokolov@cardealership.com	2020-01-15	120000.00	2025-04-22 04:44:26.530273+03
2	Козлова Ирина Александровна	Менеджер по продажам	+79160002233	kozlova@cardealership.com	2021-03-10	110000.00	2025-04-22 04:44:26.530273+03
3	Новиков Денис Олегович	Старший менеджер	+79160003344	novikov@cardealership.com	2019-05-20	150000.00	2025-04-22 04:44:26.530273+03
4	Морозова Татьяна Сергеевна	Сервисный менеджер	+79160004455	morozova@cardealership.com	2022-02-15	100000.00	2025-04-22 04:44:26.530273+03
5	Павлов Игорь Николаевич	Технический специалист	+79160005566	pavlov@cardealership.com	2021-07-01	90000.00	2025-04-22 04:44:26.530273+03
6	Власова Екатерина Андреевна	Маркетолог	+79160006677	vlasova@cardealership.com	2022-04-10	95000.00	2025-04-22 04:44:26.530273+03
7	Громов Михаил Дмитриевич	Директор	+79160007788	gromov@cardealership.com	2018-11-05	200000.00	2025-04-22 04:44:26.530273+03
8	Титова Анна Владимировна	Бухгалтер	+79160008899	titova@cardealership.com	2020-09-12	85000.00	2025-04-22 04:44:26.530273+03
9	Филиппов Артем Сергеевич	Менеджер по запчастям	+79160009900	filippov@cardealership.com	2021-12-01	80000.00	2025-04-22 04:44:26.530273+03
10	Семенова Юлия Игоревна	Администратор	+79160001010	semenova@cardealership.com	2022-06-20	75000.00	2025-04-22 04:44:26.530273+03
\.


--
-- TOC entry 4997 (class 0 OID 25810)
-- Dependencies: 234
-- Data for Name: inventory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory (inventory_id, quantity, location, last_update, car_id) FROM stdin;
1	2	Сектор A, ряд 1	2025-04-22 04:45:17.452319+03	1
2	1	Сектор A, ряд 2	2025-04-22 04:45:17.452319+03	2
3	3	Сектор B, ряд 1	2025-04-22 04:45:17.452319+03	3
4	0	Сектор B, ряд 2	2025-04-22 04:45:17.452319+03	4
5	2	Сектор C, ряд 1	2025-04-22 04:45:17.452319+03	5
6	1	Сектор C, ряд 2	2025-04-22 04:45:17.452319+03	6
7	0	Сектор D, ряд 1	2025-04-22 04:45:17.452319+03	7
8	1	Сектор D, ряд 2	2025-04-22 04:45:17.452319+03	8
9	3	Сектор E, ряд 1	2025-04-22 04:45:17.452319+03	9
10	2	Сектор E, ряд 2	2025-04-22 04:45:17.452319+03	10
\.


--
-- TOC entry 4983 (class 0 OID 25668)
-- Dependencies: 220
-- Data for Name: manufacturers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.manufacturers (manufacturer_id, name, country) FROM stdin;
1	Toyota	Japan
2	Volkswagen	Germany
3	Ford	USA
4	BMW	Germany
5	Mercedes-Benz	Germany
6	Audi	Germany
7	Hyundai	South Korea
8	Kia	South Korea
9	Lada	Russia
10	Renault	France
\.


--
-- TOC entry 4999 (class 0 OID 25827)
-- Dependencies: 236
-- Data for Name: promotions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.promotions (promotion_id, title, description, discount, start_date, end_date, status, created_at) FROM stdin;
\.


--
-- TOC entry 4995 (class 0 OID 25786)
-- Dependencies: 232
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reviews (review_id, review_date, rating, comment, customer_id, car_id, created_at) FROM stdin;
1	2023-01-15	5	Отличный автомобиль, полностью соответствует описанию!	1	4	2025-04-22 04:45:11.873886+03
2	2023-02-20	4	Хорошая машина, но дорогой сервис	3	2	2025-04-22 04:45:11.873886+03
3	2023-03-25	5	Прекрасный внедорожник, всем рекомендую!	5	3	2025-04-22 04:45:11.873886+03
4	2023-04-10	3	Нормальный автомобиль за свои деньги	2	9	2025-04-22 04:45:11.873886+03
5	2023-05-15	4	Надежный внедорожник, но расход топлива высокий	4	10	2025-04-22 04:45:11.873886+03
6	2023-06-20	5	Лучший автомобиль в своем классе!	6	5	2025-04-22 04:45:11.873886+03
7	2023-07-25	5	Роскошный седан, очень доволен покупкой	7	6	2025-04-22 04:45:11.873886+03
8	2023-08-30	2	Не понравилось обслуживание в сервисе	8	8	2025-04-22 04:45:11.873886+03
9	2023-09-05	4	Хорошая машина, но маловато места в багажнике	9	2	2025-04-22 04:45:11.873886+03
10	2023-10-15	5	Идеальное сочетание комфорта и технологий	10	7	2025-04-22 04:45:11.873886+03
\.


--
-- TOC entry 4991 (class 0 OID 25731)
-- Dependencies: 228
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales (sale_id, sale_date, sale_price, payment_method, car_id, customer_id, employee_id, created_at) FROM stdin;
\.


--
-- TOC entry 4993 (class 0 OID 25761)
-- Dependencies: 230
-- Data for Name: service_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service_records (service_id, service_date, service_type, description, cost, car_id, employee_id, created_at) FROM stdin;
1	2023-01-05	maintenance	Замена масла и фильтров	8000.00	4	5	2025-04-22 04:45:07.298252+03
2	2023-02-10	inspection	Плановый техосмотр	5000.00	2	5	2025-04-22 04:45:07.298252+03
3	2023-03-15	repair	Замена тормозных колодок	12000.00	3	4	2025-04-22 04:45:07.298252+03
4	2023-04-20	maintenance	Замена масла, фильтров, диагностика	10000.00	9	5	2025-04-22 04:45:07.298252+03
5	2023-05-25	repair	Ремонт ходовой части	25000.00	10	4	2025-04-22 04:45:07.298252+03
6	2023-06-30	inspection	Годовой техосмотр	7000.00	5	5	2025-04-22 04:45:07.298252+03
7	2023-07-05	maintenance	Замена масла в двигателе и коробке передач	15000.00	6	4	2025-04-22 04:45:07.298252+03
8	2023-08-10	repair	Замена аккумулятора	18000.00	8	5	2025-04-22 04:45:07.298252+03
9	2023-09-15	inspection	Предпродажная подготовка	6000.00	2	4	2025-04-22 04:45:07.298252+03
10	2023-10-20	maintenance	Полное ТО (масла, фильтры, жидкости)	20000.00	7	5	2025-04-22 04:45:07.298252+03
\.


--
-- TOC entry 5002 (class 0 OID 25870)
-- Dependencies: 241
-- Data for Name: system_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_users (user_id, username, password_hash, full_name, email, is_active, last_login, created_at, updated_at) FROM stdin;
1	admin	$2a$10$N9qo8uLOickgx2ZMRZoMyMrq4H3d3U7HrqWZJZ6k1TjOWYb5yY/G	Администратор	admin@gmail.com	t	\N	2025-04-22 04:36:31.946284+03	2025-04-22 04:36:31.946284+03
\.


--
-- TOC entry 5005 (class 0 OID 25896)
-- Dependencies: 244
-- Data for Name: user_role_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_role_mapping (user_id, role_id) FROM stdin;
1	1
\.


--
-- TOC entry 5004 (class 0 OID 25886)
-- Dependencies: 243
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_roles (role_id, role_name, description) FROM stdin;
1	admin	Полный доступ ко всем функциям системы
2	manager	Доступ к управлению продажами и клиентами
3	service	Доступ к сервисным функциям
\.


--
-- TOC entry 5024 (class 0 OID 0)
-- Dependencies: 217
-- Name: car_categories_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.car_categories_category_id_seq', 10, true);


--
-- TOC entry 5025 (class 0 OID 0)
-- Dependencies: 221
-- Name: cars_car_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cars_car_id_seq', 10, true);


--
-- TOC entry 5026 (class 0 OID 0)
-- Dependencies: 223
-- Name: customers_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customers_customer_id_seq', 10, true);


--
-- TOC entry 5027 (class 0 OID 0)
-- Dependencies: 225
-- Name: employees_employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employees_employee_id_seq', 10, true);


--
-- TOC entry 5028 (class 0 OID 0)
-- Dependencies: 233
-- Name: inventory_inventory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inventory_inventory_id_seq', 10, true);


--
-- TOC entry 5029 (class 0 OID 0)
-- Dependencies: 219
-- Name: manufacturers_manufacturer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.manufacturers_manufacturer_id_seq', 10, true);


--
-- TOC entry 5030 (class 0 OID 0)
-- Dependencies: 235
-- Name: promotions_promotion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.promotions_promotion_id_seq', 1, false);


--
-- TOC entry 5031 (class 0 OID 0)
-- Dependencies: 231
-- Name: reviews_review_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reviews_review_id_seq', 10, true);


--
-- TOC entry 5032 (class 0 OID 0)
-- Dependencies: 227
-- Name: sales_sale_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_sale_id_seq', 1, true);


--
-- TOC entry 5033 (class 0 OID 0)
-- Dependencies: 229
-- Name: service_records_service_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.service_records_service_id_seq', 10, true);


--
-- TOC entry 5034 (class 0 OID 0)
-- Dependencies: 240
-- Name: system_users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.system_users_user_id_seq', 1, true);


--
-- TOC entry 5035 (class 0 OID 0)
-- Dependencies: 242
-- Name: user_roles_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_roles_role_id_seq', 3, true);


--
-- TOC entry 4763 (class 2606 OID 25666)
-- Name: car_categories car_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.car_categories
    ADD CONSTRAINT car_categories_pkey PRIMARY KEY (category_id);


--
-- TOC entry 4803 (class 2606 OID 25844)
-- Name: car_promotions car_promotions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.car_promotions
    ADD CONSTRAINT car_promotions_pkey PRIMARY KEY (car_id, promotion_id);


--
-- TOC entry 4767 (class 2606 OID 25689)
-- Name: cars cars_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cars
    ADD CONSTRAINT cars_pkey PRIMARY KEY (car_id);


--
-- TOC entry 4769 (class 2606 OID 25691)
-- Name: cars cars_vin_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cars
    ADD CONSTRAINT cars_vin_key UNIQUE (vin);


--
-- TOC entry 4774 (class 2606 OID 25715)
-- Name: customers customers_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_email_key UNIQUE (email);


--
-- TOC entry 4776 (class 2606 OID 25713)
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (customer_id);


--
-- TOC entry 4780 (class 2606 OID 25729)
-- Name: employees employees_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_email_key UNIQUE (email);


--
-- TOC entry 4782 (class 2606 OID 25727)
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (employee_id);


--
-- TOC entry 4797 (class 2606 OID 25820)
-- Name: inventory inventory_car_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_car_id_key UNIQUE (car_id);


--
-- TOC entry 4799 (class 2606 OID 25818)
-- Name: inventory inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_pkey PRIMARY KEY (inventory_id);


--
-- TOC entry 4765 (class 2606 OID 25673)
-- Name: manufacturers manufacturers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manufacturers
    ADD CONSTRAINT manufacturers_pkey PRIMARY KEY (manufacturer_id);


--
-- TOC entry 4801 (class 2606 OID 25839)
-- Name: promotions promotions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promotions
    ADD CONSTRAINT promotions_pkey PRIMARY KEY (promotion_id);


--
-- TOC entry 4795 (class 2606 OID 25796)
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (review_id);


--
-- TOC entry 4787 (class 2606 OID 25740)
-- Name: sales sales_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_pkey PRIMARY KEY (sale_id);


--
-- TOC entry 4791 (class 2606 OID 25772)
-- Name: service_records service_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_records
    ADD CONSTRAINT service_records_pkey PRIMARY KEY (service_id);


--
-- TOC entry 4805 (class 2606 OID 25884)
-- Name: system_users system_users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_users
    ADD CONSTRAINT system_users_email_key UNIQUE (email);


--
-- TOC entry 4807 (class 2606 OID 25880)
-- Name: system_users system_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_users
    ADD CONSTRAINT system_users_pkey PRIMARY KEY (user_id);


--
-- TOC entry 4809 (class 2606 OID 25882)
-- Name: system_users system_users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_users
    ADD CONSTRAINT system_users_username_key UNIQUE (username);


--
-- TOC entry 4815 (class 2606 OID 25900)
-- Name: user_role_mapping user_role_mapping_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_role_mapping
    ADD CONSTRAINT user_role_mapping_pkey PRIMARY KEY (user_id, role_id);


--
-- TOC entry 4811 (class 2606 OID 25893)
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (role_id);


--
-- TOC entry 4813 (class 2606 OID 25895)
-- Name: user_roles user_roles_role_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_name_key UNIQUE (role_name);


--
-- TOC entry 4770 (class 1259 OID 25704)
-- Name: idx_cars_brand_model; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cars_brand_model ON public.cars USING btree (brand, model);


--
-- TOC entry 4771 (class 1259 OID 25703)
-- Name: idx_cars_price; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cars_price ON public.cars USING btree (price);


--
-- TOC entry 4772 (class 1259 OID 25702)
-- Name: idx_cars_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cars_status ON public.cars USING btree (status);


--
-- TOC entry 4777 (class 1259 OID 25716)
-- Name: idx_customers_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_name ON public.customers USING btree (full_name);


--
-- TOC entry 4778 (class 1259 OID 25717)
-- Name: idx_customers_phone; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_phone ON public.customers USING btree (phone);


--
-- TOC entry 4792 (class 1259 OID 25808)
-- Name: idx_reviews_car; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reviews_car ON public.reviews USING btree (car_id);


--
-- TOC entry 4793 (class 1259 OID 25807)
-- Name: idx_reviews_rating; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reviews_rating ON public.reviews USING btree (rating);


--
-- TOC entry 4783 (class 1259 OID 25757)
-- Name: idx_sales_customer; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sales_customer ON public.sales USING btree (customer_id);


--
-- TOC entry 4784 (class 1259 OID 25756)
-- Name: idx_sales_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sales_date ON public.sales USING btree (sale_date);


--
-- TOC entry 4785 (class 1259 OID 25759)
-- Name: idx_sales_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sales_employee ON public.sales USING btree (employee_id);


--
-- TOC entry 4788 (class 1259 OID 25784)
-- Name: idx_service_car; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_service_car ON public.service_records USING btree (car_id);


--
-- TOC entry 4789 (class 1259 OID 25783)
-- Name: idx_service_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_service_date ON public.service_records USING btree (service_date);


--
-- TOC entry 4830 (class 2620 OID 25868)
-- Name: sales trg_check_inventory_before_sale; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_check_inventory_before_sale BEFORE INSERT ON public.sales FOR EACH ROW EXECUTE FUNCTION public.check_car_inventory();


--
-- TOC entry 4831 (class 2620 OID 25866)
-- Name: sales trg_update_car_status; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_update_car_status AFTER INSERT ON public.sales FOR EACH ROW EXECUTE FUNCTION public.update_car_status_after_sale();


--
-- TOC entry 4832 (class 2620 OID 25912)
-- Name: system_users trg_update_last_login; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_update_last_login BEFORE UPDATE ON public.system_users FOR EACH ROW WHEN ((old.is_active IS DISTINCT FROM new.is_active)) EXECUTE FUNCTION public.update_last_login();


--
-- TOC entry 4826 (class 2606 OID 25845)
-- Name: car_promotions car_promotions_car_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.car_promotions
    ADD CONSTRAINT car_promotions_car_id_fkey FOREIGN KEY (car_id) REFERENCES public.cars(car_id);


--
-- TOC entry 4827 (class 2606 OID 25850)
-- Name: car_promotions car_promotions_promotion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.car_promotions
    ADD CONSTRAINT car_promotions_promotion_id_fkey FOREIGN KEY (promotion_id) REFERENCES public.promotions(promotion_id);


--
-- TOC entry 4816 (class 2606 OID 25697)
-- Name: cars cars_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cars
    ADD CONSTRAINT cars_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.car_categories(category_id);


--
-- TOC entry 4817 (class 2606 OID 25692)
-- Name: cars cars_manufacturer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cars
    ADD CONSTRAINT cars_manufacturer_id_fkey FOREIGN KEY (manufacturer_id) REFERENCES public.manufacturers(manufacturer_id);


--
-- TOC entry 4825 (class 2606 OID 25821)
-- Name: inventory inventory_car_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_car_id_fkey FOREIGN KEY (car_id) REFERENCES public.cars(car_id);


--
-- TOC entry 4823 (class 2606 OID 25802)
-- Name: reviews reviews_car_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_car_id_fkey FOREIGN KEY (car_id) REFERENCES public.cars(car_id);


--
-- TOC entry 4824 (class 2606 OID 25797)
-- Name: reviews reviews_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(customer_id);


--
-- TOC entry 4818 (class 2606 OID 25741)
-- Name: sales sales_car_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_car_id_fkey FOREIGN KEY (car_id) REFERENCES public.cars(car_id);


--
-- TOC entry 4819 (class 2606 OID 25746)
-- Name: sales sales_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(customer_id);


--
-- TOC entry 4820 (class 2606 OID 25751)
-- Name: sales sales_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(employee_id);


--
-- TOC entry 4821 (class 2606 OID 25773)
-- Name: service_records service_records_car_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_records
    ADD CONSTRAINT service_records_car_id_fkey FOREIGN KEY (car_id) REFERENCES public.cars(car_id);


--
-- TOC entry 4822 (class 2606 OID 25778)
-- Name: service_records service_records_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_records
    ADD CONSTRAINT service_records_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(employee_id);


--
-- TOC entry 4828 (class 2606 OID 25906)
-- Name: user_role_mapping user_role_mapping_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_role_mapping
    ADD CONSTRAINT user_role_mapping_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.user_roles(role_id);


--
-- TOC entry 4829 (class 2606 OID 25901)
-- Name: user_role_mapping user_role_mapping_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_role_mapping
    ADD CONSTRAINT user_role_mapping_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.system_users(user_id);


-- Completed on 2025-04-22 05:49:38

--
-- PostgreSQL database dump complete
--

--
-- Database "gibdd" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

-- Started on 2025-04-22 05:49:38

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 4864 (class 1262 OID 24595)
-- Name: gibdd; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE gibdd WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'ru-RU';


ALTER DATABASE gibdd OWNER TO postgres;

\connect gibdd

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 4865 (class 0 OID 0)
-- Name: gibdd; Type: DATABASE PROPERTIES; Schema: -; Owner: postgres
--

ALTER DATABASE gibdd SET client_encoding TO 'UTF8';


\connect gibdd

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 226 (class 1259 OID 25623)
-- Name: cars; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cars (
    car_id integer NOT NULL,
    vin character varying(17),
    brand character varying(50) NOT NULL,
    model character varying(50) NOT NULL,
    year integer,
    color character varying(30),
    registration_number character varying(20) NOT NULL,
    owner_id integer,
    car_type character varying(30),
    fuel_type character varying(20),
    number_of_doors integer,
    number_of_seats integer,
    weight numeric(10,2),
    engine_capacity numeric(5,2),
    transmission_type character varying(30),
    drive_type character varying(20)
);


ALTER TABLE public.cars OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 25622)
-- Name: cars_car_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cars_car_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cars_car_id_seq OWNER TO postgres;

--
-- TOC entry 4866 (class 0 OID 0)
-- Dependencies: 225
-- Name: cars_car_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cars_car_id_seq OWNED BY public.cars.car_id;


--
-- TOC entry 220 (class 1259 OID 25571)
-- Name: inspector; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inspector (
    inspector_id integer NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    middle_name character varying(50),
    badge_number character varying(20) NOT NULL,
    rank character varying(30),
    department_id integer
);


ALTER TABLE public.inspector OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 25570)
-- Name: inspector_inspector_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inspector_inspector_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inspector_inspector_id_seq OWNER TO postgres;

--
-- TOC entry 4867 (class 0 OID 0)
-- Dependencies: 219
-- Name: inspector_inspector_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inspector_inspector_id_seq OWNED BY public.inspector.inspector_id;


--
-- TOC entry 218 (class 1259 OID 25545)
-- Name: owner; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.owner (
    owner_id integer NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    middle_name character varying(50),
    date_of_birth date NOT NULL,
    phone character varying(15),
    address character varying(255),
    driver_license_number character varying(20) NOT NULL,
    driver_license_issue_date date NOT NULL,
    driver_license_expiration_date date NOT NULL
);


ALTER TABLE public.owner OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 25544)
-- Name: owner_owner_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.owner_owner_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.owner_owner_id_seq OWNER TO postgres;

--
-- TOC entry 4868 (class 0 OID 0)
-- Dependencies: 217
-- Name: owner_owner_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.owner_owner_id_seq OWNED BY public.owner.owner_id;


--
-- TOC entry 222 (class 1259 OID 25599)
-- Name: registration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.registration (
    registration_id integer NOT NULL,
    car_id integer,
    registration_date date NOT NULL,
    expiration_date date NOT NULL,
    registration_office character varying(100),
    registration_fee numeric(10,2)
);


ALTER TABLE public.registration OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 25598)
-- Name: registration_registration_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.registration_registration_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.registration_registration_id_seq OWNER TO postgres;

--
-- TOC entry 4869 (class 0 OID 0)
-- Dependencies: 221
-- Name: registration_registration_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.registration_registration_id_seq OWNED BY public.registration.registration_id;


--
-- TOC entry 224 (class 1259 OID 25612)
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    username character varying(50) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(20) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['admin'::character varying, 'user'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 25611)
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_user_id_seq OWNER TO postgres;

--
-- TOC entry 4870 (class 0 OID 0)
-- Dependencies: 223
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- TOC entry 228 (class 1259 OID 25639)
-- Name: violations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.violations (
    violation_id integer NOT NULL,
    car_id integer,
    violation_date timestamp without time zone NOT NULL,
    violation_type character varying(100) NOT NULL,
    fine_amount numeric(10,2) NOT NULL,
    status character varying(20) DEFAULT 'new'::character varying NOT NULL,
    inspector_id integer,
    description text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.violations OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 25638)
-- Name: violations_violation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.violations_violation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.violations_violation_id_seq OWNER TO postgres;

--
-- TOC entry 4871 (class 0 OID 0)
-- Dependencies: 227
-- Name: violations_violation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.violations_violation_id_seq OWNED BY public.violations.violation_id;


--
-- TOC entry 4671 (class 2604 OID 25626)
-- Name: cars car_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cars ALTER COLUMN car_id SET DEFAULT nextval('public.cars_car_id_seq'::regclass);


--
-- TOC entry 4667 (class 2604 OID 25574)
-- Name: inspector inspector_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspector ALTER COLUMN inspector_id SET DEFAULT nextval('public.inspector_inspector_id_seq'::regclass);


--
-- TOC entry 4666 (class 2604 OID 25548)
-- Name: owner owner_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.owner ALTER COLUMN owner_id SET DEFAULT nextval('public.owner_owner_id_seq'::regclass);


--
-- TOC entry 4668 (class 2604 OID 25602)
-- Name: registration registration_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registration ALTER COLUMN registration_id SET DEFAULT nextval('public.registration_registration_id_seq'::regclass);


--
-- TOC entry 4669 (class 2604 OID 25615)
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- TOC entry 4672 (class 2604 OID 25642)
-- Name: violations violation_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.violations ALTER COLUMN violation_id SET DEFAULT nextval('public.violations_violation_id_seq'::regclass);


--
-- TOC entry 4856 (class 0 OID 25623)
-- Dependencies: 226
-- Data for Name: cars; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cars (car_id, vin, brand, model, year, color, registration_number, owner_id, car_type, fuel_type, number_of_doors, number_of_seats, weight, engine_capacity, transmission_type, drive_type) FROM stdin;
1	XTA21099765432101	Lada	Granta	2020	Белый	А123БВ777	1	Седан	Бензин	4	5	1080.00	1.60	Механика	Передний
2	XTA21099876543210	Kia	Rio	2021	Серый	О456ТК777	2	Седан	Бензин	4	5	1150.00	1.60	Автомат	Передний
3	XTA21099987654321	Hyundai	Creta	2022	Черный	Е789ХХ777	3	Кроссовер	Бензин	5	5	1320.00	2.00	Автомат	Полный
\.


--
-- TOC entry 4850 (class 0 OID 25571)
-- Dependencies: 220
-- Data for Name: inspector; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inspector (inspector_id, first_name, last_name, middle_name, badge_number, rank, department_id) FROM stdin;
1	Алексей	Смирнов	Алексеевич	ГИБДД-001	Старший инспектор	1
2	Дмитрий	Кузнецов	Дмитриевич	ГИБДД-002	Инспектор	1
3	Елена	Васильева	Игоревна	ГИБДД-003	Младший инспектор	2
\.


--
-- TOC entry 4848 (class 0 OID 25545)
-- Dependencies: 218
-- Data for Name: owner; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.owner (owner_id, first_name, last_name, middle_name, date_of_birth, phone, address, driver_license_number, driver_license_issue_date, driver_license_expiration_date) FROM stdin;
1	Иван	Иванов	Иванович	1985-05-15	+79161234567	г. Москва, ул. Ленина, д. 1	1234567890	2015-06-20	2025-06-20
2	Петр	Петров	Петрович	1990-11-22	+79167654321	г. Санкт-Петербург, ул. Пушкина, д. 10	0987654321	2018-03-10	2028-03-10
3	Анна	Сидорова	Сергеевна	1995-02-28	+79169998877	г. Казань, ул. Гагарина, д. 5	1122334455	2020-01-15	2030-01-15
\.


--
-- TOC entry 4852 (class 0 OID 25599)
-- Dependencies: 222
-- Data for Name: registration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.registration (registration_id, car_id, registration_date, expiration_date, registration_office, registration_fee) FROM stdin;
1	1	2022-01-10	2027-01-10	ГИБДД Москвы	2000.00
2	2	2021-05-15	2026-05-15	ГИБДД Санкт-Петербурга	3500.00
3	3	2023-03-20	2028-03-20	ГИБДД Казани	2500.00
4	1	2020-05-15	2025-05-15	МО ГИБДД №1 г. Москвы	2000.00
5	2	2021-08-25	2026-08-25	МО ГИБДД №2 г. Москвы	2500.00
6	3	2022-11-30	2027-11-30	МО ГИБДД №3 г. Москвы	3000.00
\.


--
-- TOC entry 4854 (class 0 OID 25612)
-- Dependencies: 224
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (user_id, username, password_hash, role, created_at) FROM stdin;
2	user	$2a$10$XuTN9GHsWj6QJ1rr5ZOhA.D8B3UVfE5XaQH6KZ6r7WtVlW8zYqQ1C	user	2025-04-21 20:06:13.784067
3	admin	$2b$12$ef8zM0i/cx/RDfD7jlvwOex7x1m/J2pX2p763s0FFikKSMPsnfDei	admin	2025-04-21 22:46:05.518989
\.


--
-- TOC entry 4858 (class 0 OID 25639)
-- Dependencies: 228
-- Data for Name: violations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.violations (violation_id, car_id, violation_date, violation_type, fine_amount, status, inspector_id, description, created_at, updated_at) FROM stdin;
1	1	2024-01-15 08:30:00	Превышение скорости	1500.00	paid	1	Превышение на 20 км/ч	2025-04-21 23:05:37.499465	2025-04-21 23:05:37.499465
2	1	2024-02-20 14:15:00	Парковка в неположенном месте	3000.00	unpaid	2	Парковка на газоне	2025-04-21 23:05:37.499465	2025-04-21 23:05:37.499465
3	2	2024-03-10 09:45:00	Проезд на красный свет	5000.00	active	1	Перекресток ул. Ленина и ул. Пушкина	2025-04-21 23:05:37.499465	2025-04-21 23:05:37.499465
4	3	2024-04-05 17:30:00	Отсутствие страховки	800.00	new	3	Проверка на посту ДПС	2025-04-21 23:05:37.499465	2025-04-21 23:05:37.499465
5	2	2024-04-12 11:20:00	Непристегнутый ремень	1000.00	processed	2	Рейд "Безопасность"	2025-04-21 23:05:37.499465	2025-04-21 23:05:37.499465
6	1	2024-05-01 16:45:00	Превышение скорости	2500.00	unpaid	3	Превышение на 40 км/ч	2025-04-21 23:05:56.955183	2025-04-21 23:05:56.955183
7	3	2024-05-10 10:10:00	Использование телефона	1500.00	active	1	Водитель разговаривал по телефону	2025-04-21 23:05:56.955183	2025-04-21 23:05:56.955183
\.


--
-- TOC entry 4872 (class 0 OID 0)
-- Dependencies: 225
-- Name: cars_car_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cars_car_id_seq', 3, true);


--
-- TOC entry 4873 (class 0 OID 0)
-- Dependencies: 219
-- Name: inspector_inspector_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inspector_inspector_id_seq', 3, true);


--
-- TOC entry 4874 (class 0 OID 0)
-- Dependencies: 217
-- Name: owner_owner_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.owner_owner_id_seq', 3, true);


--
-- TOC entry 4875 (class 0 OID 0)
-- Dependencies: 221
-- Name: registration_registration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.registration_registration_id_seq', 6, true);


--
-- TOC entry 4876 (class 0 OID 0)
-- Dependencies: 223
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_user_id_seq', 3, true);


--
-- TOC entry 4877 (class 0 OID 0)
-- Dependencies: 227
-- Name: violations_violation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.violations_violation_id_seq', 7, true);


--
-- TOC entry 4692 (class 2606 OID 25628)
-- Name: cars cars_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cars
    ADD CONSTRAINT cars_pkey PRIMARY KEY (car_id);


--
-- TOC entry 4694 (class 2606 OID 25632)
-- Name: cars cars_registration_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cars
    ADD CONSTRAINT cars_registration_number_key UNIQUE (registration_number);


--
-- TOC entry 4696 (class 2606 OID 25630)
-- Name: cars cars_vin_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cars
    ADD CONSTRAINT cars_vin_key UNIQUE (vin);


--
-- TOC entry 4682 (class 2606 OID 25578)
-- Name: inspector inspector_badge_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspector
    ADD CONSTRAINT inspector_badge_number_key UNIQUE (badge_number);


--
-- TOC entry 4684 (class 2606 OID 25576)
-- Name: inspector inspector_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspector
    ADD CONSTRAINT inspector_pkey PRIMARY KEY (inspector_id);


--
-- TOC entry 4678 (class 2606 OID 25552)
-- Name: owner owner_driver_license_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.owner
    ADD CONSTRAINT owner_driver_license_number_key UNIQUE (driver_license_number);


--
-- TOC entry 4680 (class 2606 OID 25550)
-- Name: owner owner_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.owner
    ADD CONSTRAINT owner_pkey PRIMARY KEY (owner_id);


--
-- TOC entry 4686 (class 2606 OID 25604)
-- Name: registration registration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registration
    ADD CONSTRAINT registration_pkey PRIMARY KEY (registration_id);


--
-- TOC entry 4688 (class 2606 OID 25619)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- TOC entry 4690 (class 2606 OID 25621)
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- TOC entry 4698 (class 2606 OID 25649)
-- Name: violations violations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.violations
    ADD CONSTRAINT violations_pkey PRIMARY KEY (violation_id);


--
-- TOC entry 4699 (class 2606 OID 25633)
-- Name: cars cars_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cars
    ADD CONSTRAINT cars_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.owner(owner_id);


--
-- TOC entry 4700 (class 2606 OID 25650)
-- Name: violations violations_car_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.violations
    ADD CONSTRAINT violations_car_id_fkey FOREIGN KEY (car_id) REFERENCES public.cars(car_id);


--
-- TOC entry 4701 (class 2606 OID 25655)
-- Name: violations violations_inspector_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.violations
    ADD CONSTRAINT violations_inspector_id_fkey FOREIGN KEY (inspector_id) REFERENCES public.inspector(inspector_id);


-- Completed on 2025-04-22 05:49:38

--
-- PostgreSQL database dump complete
--

--
-- Database "home_finance_db" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

-- Started on 2025-04-22 05:49:38

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 4876 (class 1262 OID 25077)
-- Name: home_finance_db; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE home_finance_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'ru-RU';


ALTER DATABASE home_finance_db OWNER TO postgres;

\connect home_finance_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 217 (class 1259 OID 25443)
-- Name: budgets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.budgets (
    budgetid integer NOT NULL,
    categoryid integer NOT NULL,
    budgetlimit numeric(10,2) NOT NULL,
    budgetperiod character varying(20) NOT NULL,
    startdate timestamp without time zone NOT NULL,
    enddate timestamp without time zone
);


ALTER TABLE public.budgets OWNER TO postgres;

--
-- TOC entry 218 (class 1259 OID 25446)
-- Name: budgets_budgetid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.budgets_budgetid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.budgets_budgetid_seq OWNER TO postgres;

--
-- TOC entry 4878 (class 0 OID 0)
-- Dependencies: 218
-- Name: budgets_budgetid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.budgets_budgetid_seq OWNED BY public.budgets.budgetid;


--
-- TOC entry 219 (class 1259 OID 25447)
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    categoryid integer NOT NULL,
    categoryname character varying(100) NOT NULL,
    categorytype character varying(10) NOT NULL,
    CONSTRAINT categories_categorytype_check CHECK (((categorytype)::text = ANY (ARRAY[('income'::character varying)::text, ('expense'::character varying)::text])))
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- TOC entry 220 (class 1259 OID 25451)
-- Name: categories_categoryid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categories_categoryid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categories_categoryid_seq OWNER TO postgres;

--
-- TOC entry 4879 (class 0 OID 0)
-- Dependencies: 220
-- Name: categories_categoryid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categories_categoryid_seq OWNED BY public.categories.categoryid;


--
-- TOC entry 221 (class 1259 OID 25452)
-- Name: investments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.investments (
    investmentid integer NOT NULL,
    amount numeric(10,2) NOT NULL,
    investmenttype character varying(50) NOT NULL,
    investmentstartdate timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    investmentenddate timestamp without time zone,
    currentvalue numeric(10,2) NOT NULL,
    profitloss numeric(10,2) NOT NULL
);


ALTER TABLE public.investments OWNER TO postgres;

--
-- TOC entry 222 (class 1259 OID 25456)
-- Name: investments_investmentid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.investments_investmentid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.investments_investmentid_seq OWNER TO postgres;

--
-- TOC entry 4880 (class 0 OID 0)
-- Dependencies: 222
-- Name: investments_investmentid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.investments_investmentid_seq OWNED BY public.investments.investmentid;


--
-- TOC entry 223 (class 1259 OID 25457)
-- Name: report_transaction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.report_transaction (
    reportid integer NOT NULL,
    transactionid integer NOT NULL
);


ALTER TABLE public.report_transaction OWNER TO postgres;

--
-- TOC entry 224 (class 1259 OID 25460)
-- Name: reports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reports (
    reportid integer NOT NULL,
    reportperiod character varying(20) NOT NULL,
    totalincome numeric(10,2) NOT NULL,
    totalexpenses numeric(10,2) NOT NULL,
    netprofit numeric(10,2) NOT NULL,
    reportcreationdate timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.reports OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 25464)
-- Name: reports_reportid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reports_reportid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reports_reportid_seq OWNER TO postgres;

--
-- TOC entry 4881 (class 0 OID 0)
-- Dependencies: 225
-- Name: reports_reportid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reports_reportid_seq OWNED BY public.reports.reportid;


--
-- TOC entry 226 (class 1259 OID 25465)
-- Name: savings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.savings (
    savingsid integer NOT NULL,
    amount numeric(10,2) NOT NULL,
    savingstype character varying(50) NOT NULL,
    startdate timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    enddate timestamp without time zone,
    savingsgoal character varying(100)
);


ALTER TABLE public.savings OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 25469)
-- Name: savings_savingsid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.savings_savingsid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.savings_savingsid_seq OWNER TO postgres;

--
-- TOC entry 4882 (class 0 OID 0)
-- Dependencies: 227
-- Name: savings_savingsid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.savings_savingsid_seq OWNED BY public.savings.savingsid;


--
-- TOC entry 228 (class 1259 OID 25470)
-- Name: transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transactions (
    transactionid integer NOT NULL,
    transactiondate timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    amount numeric(10,2) NOT NULL,
    categoryid integer NOT NULL,
    paymentmethod character varying(50) NOT NULL,
    notes text,
    userid integer,
    transactiontype character varying(10)
);


ALTER TABLE public.transactions OWNER TO postgres;

--
-- TOC entry 229 (class 1259 OID 25476)
-- Name: transactions_transactionid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.transactions_transactionid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.transactions_transactionid_seq OWNER TO postgres;

--
-- TOC entry 4883 (class 0 OID 0)
-- Dependencies: 229
-- Name: transactions_transactionid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.transactions_transactionid_seq OWNED BY public.transactions.transactionid;


--
-- TOC entry 230 (class 1259 OID 25477)
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    userid integer NOT NULL,
    name character varying(100) NOT NULL,
    email character varying(100) NOT NULL,
    password character varying(255) NOT NULL,
    registrationdate timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lastlogin timestamp without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- TOC entry 231 (class 1259 OID 25481)
-- Name: users_userid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_userid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_userid_seq OWNER TO postgres;

--
-- TOC entry 4884 (class 0 OID 0)
-- Dependencies: 231
-- Name: users_userid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_userid_seq OWNED BY public.users.userid;


--
-- TOC entry 4675 (class 2604 OID 25482)
-- Name: budgets budgetid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budgets ALTER COLUMN budgetid SET DEFAULT nextval('public.budgets_budgetid_seq'::regclass);


--
-- TOC entry 4676 (class 2604 OID 25483)
-- Name: categories categoryid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories ALTER COLUMN categoryid SET DEFAULT nextval('public.categories_categoryid_seq'::regclass);


--
-- TOC entry 4677 (class 2604 OID 25484)
-- Name: investments investmentid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investments ALTER COLUMN investmentid SET DEFAULT nextval('public.investments_investmentid_seq'::regclass);


--
-- TOC entry 4679 (class 2604 OID 25485)
-- Name: reports reportid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports ALTER COLUMN reportid SET DEFAULT nextval('public.reports_reportid_seq'::regclass);


--
-- TOC entry 4681 (class 2604 OID 25486)
-- Name: savings savingsid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.savings ALTER COLUMN savingsid SET DEFAULT nextval('public.savings_savingsid_seq'::regclass);


--
-- TOC entry 4683 (class 2604 OID 25487)
-- Name: transactions transactionid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions ALTER COLUMN transactionid SET DEFAULT nextval('public.transactions_transactionid_seq'::regclass);


--
-- TOC entry 4685 (class 2604 OID 25488)
-- Name: users userid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN userid SET DEFAULT nextval('public.users_userid_seq'::regclass);


--
-- TOC entry 4856 (class 0 OID 25443)
-- Dependencies: 217
-- Data for Name: budgets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.budgets (budgetid, categoryid, budgetlimit, budgetperiod, startdate, enddate) FROM stdin;
1	3	300.00	Monthly	2023-10-01 00:00:00	2023-10-31 23:59:59
2	4	150.00	Monthly	2023-10-01 00:00:00	2023-10-31 23:59:59
3	5	100.00	Monthly	2023-10-01 00:00:00	2023-10-31 23:59:59
4	6	50.00	Monthly	2023-10-01 00:00:00	2023-10-31 23:59:59
\.


--
-- TOC entry 4858 (class 0 OID 25447)
-- Dependencies: 219
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (categoryid, categoryname, categorytype) FROM stdin;
1	Salary	income
2	Freelance	income
3	Grocery	expense
4	Utilities	expense
5	Entertainment	expense
6	Transport	expense
7	Savings	income
8	Investments	income
\.


--
-- TOC entry 4860 (class 0 OID 25452)
-- Dependencies: 221
-- Data for Name: investments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.investments (investmentid, amount, investmenttype, investmentstartdate, investmentenddate, currentvalue, profitloss) FROM stdin;
1	1000.00	Stocks	2023-10-01 00:00:00	2024-10-01 00:00:00	1050.00	50.00
2	500.00	Bonds	2023-10-01 00:00:00	2025-10-01 00:00:00	520.00	20.00
3	2000.00	Mutual Funds	2023-10-01 00:00:00	2030-10-01 00:00:00	2100.00	100.00
\.


--
-- TOC entry 4862 (class 0 OID 25457)
-- Dependencies: 223
-- Data for Name: report_transaction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.report_transaction (reportid, transactionid) FROM stdin;
1	1
1	2
1	3
1	4
1	5
1	6
1	7
1	8
\.


--
-- TOC entry 4863 (class 0 OID 25460)
-- Dependencies: 224
-- Data for Name: reports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reports (reportid, reportperiod, totalincome, totalexpenses, netprofit, reportcreationdate) FROM stdin;
1	October 2023	2700.00	180.50	2519.50	2023-10-31 23:59:59
2	November 2023	3000.00	200.00	2800.00	2023-11-30 23:59:59
\.


--
-- TOC entry 4865 (class 0 OID 25465)
-- Dependencies: 226
-- Data for Name: savings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.savings (savingsid, amount, savingstype, startdate, enddate, savingsgoal) FROM stdin;
1	1000.00	Emergency Fund	2023-10-01 00:00:00	2024-10-01 00:00:00	Save for emergencies
2	500.00	Vacation Fund	2023-10-01 00:00:00	2024-05-01 00:00:00	Save for vacation
3	2000.00	Retirement Fund	2023-10-01 00:00:00	2040-10-01 00:00:00	Save for retirement
\.


--
-- TOC entry 4867 (class 0 OID 25470)
-- Dependencies: 228
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transactions (transactionid, transactiondate, amount, categoryid, paymentmethod, notes, userid, transactiontype) FROM stdin;
1	2023-10-01 09:00:00	1500.00	1	Bank Transfer	Monthly salary	\N	\N
2	2023-10-02 10:30:00	200.00	2	PayPal	Freelance project payment	\N	\N
3	2023-10-03 12:15:00	75.50	3	Credit Card	Weekly grocery shopping	\N	\N
4	2023-10-04 18:00:00	50.00	4	Debit Card	Electricity bill	\N	\N
5	2023-10-05 20:00:00	25.00	5	Cash	Movie tickets	\N	\N
6	2023-10-06 08:45:00	30.00	6	Credit Card	Bus fare	\N	\N
7	2023-10-07 14:00:00	1000.00	7	Bank Transfer	Monthly savings	\N	\N
8	2023-10-08 16:30:00	500.00	8	Bank Transfer	Stock investment	\N	\N
9	2025-03-22 00:00:00	1500.00	1	СБП	123	5	\N
10	2025-03-22 00:00:00	200.00	8	СБП	123	5	\N
11	2025-03-22 00:00:00	-200.00	1	СБП	123	5	\N
12	2025-03-22 00:00:00	1000.00	2	СБП	123	5	expense
13	2025-03-22 00:00:00	100.00	2	СБП	123	5	expense
14	2025-03-22 00:00:00	1000.00	1	СБП	123	5	income
15	2025-03-22 00:00:00	5000.00	1	СБП	123	5	income
16	2025-03-22 00:00:00	2456.00	2	СБП	231	5	expense
17	2025-03-22 00:00:00	200.00	1	СБП	123	5	income
\.


--
-- TOC entry 4869 (class 0 OID 25477)
-- Dependencies: 230
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (userid, name, email, password, registrationdate, lastlogin) FROM stdin;
1	John Doe	john.doe@example.com	password123	2025-03-15 02:01:06.44975	2023-10-01 12:00:00
2	Jane Smith	jane.smith@example.com	securepass	2025-03-15 02:01:06.44975	2023-10-02 14:30:00
3	Alice Johnson	alice.johnson@example.com	alicepass	2025-03-15 02:01:06.44975	2023-10-03 09:15:00
4	Bob Brown	bob.brown@example.com	bobpass	2025-03-15 02:01:06.44975	2023-10-04 17:45:00
5	Jonny	admin@gmail.com	$2b$10$5vRFtScZBqDmjW2EB8v7K.DwkN7rqUcwlGUZJdoi0CKk2eqBxTQBG	2025-03-22 02:57:17.651792	\N
\.


--
-- TOC entry 4885 (class 0 OID 0)
-- Dependencies: 218
-- Name: budgets_budgetid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.budgets_budgetid_seq', 4, true);


--
-- TOC entry 4886 (class 0 OID 0)
-- Dependencies: 220
-- Name: categories_categoryid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categories_categoryid_seq', 8, true);


--
-- TOC entry 4887 (class 0 OID 0)
-- Dependencies: 222
-- Name: investments_investmentid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.investments_investmentid_seq', 3, true);


--
-- TOC entry 4888 (class 0 OID 0)
-- Dependencies: 225
-- Name: reports_reportid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reports_reportid_seq', 2, true);


--
-- TOC entry 4889 (class 0 OID 0)
-- Dependencies: 227
-- Name: savings_savingsid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.savings_savingsid_seq', 3, true);


--
-- TOC entry 4890 (class 0 OID 0)
-- Dependencies: 229
-- Name: transactions_transactionid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.transactions_transactionid_seq', 17, true);


--
-- TOC entry 4891 (class 0 OID 0)
-- Dependencies: 231
-- Name: users_userid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_userid_seq', 6, true);


--
-- TOC entry 4689 (class 2606 OID 25490)
-- Name: budgets budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_pkey PRIMARY KEY (budgetid);


--
-- TOC entry 4691 (class 2606 OID 25492)
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (categoryid);


--
-- TOC entry 4693 (class 2606 OID 25494)
-- Name: investments investments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investments
    ADD CONSTRAINT investments_pkey PRIMARY KEY (investmentid);


--
-- TOC entry 4695 (class 2606 OID 25496)
-- Name: report_transaction report_transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_transaction
    ADD CONSTRAINT report_transaction_pkey PRIMARY KEY (reportid, transactionid);


--
-- TOC entry 4697 (class 2606 OID 25498)
-- Name: reports reports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_pkey PRIMARY KEY (reportid);


--
-- TOC entry 4699 (class 2606 OID 25500)
-- Name: savings savings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.savings
    ADD CONSTRAINT savings_pkey PRIMARY KEY (savingsid);


--
-- TOC entry 4701 (class 2606 OID 25502)
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (transactionid);


--
-- TOC entry 4703 (class 2606 OID 25504)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 4705 (class 2606 OID 25506)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (userid);


--
-- TOC entry 4706 (class 2606 OID 25507)
-- Name: budgets budgets_categoryid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_categoryid_fkey FOREIGN KEY (categoryid) REFERENCES public.categories(categoryid) ON DELETE CASCADE;


--
-- TOC entry 4707 (class 2606 OID 25512)
-- Name: report_transaction report_transaction_reportid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_transaction
    ADD CONSTRAINT report_transaction_reportid_fkey FOREIGN KEY (reportid) REFERENCES public.reports(reportid);


--
-- TOC entry 4708 (class 2606 OID 25517)
-- Name: report_transaction report_transaction_transactionid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_transaction
    ADD CONSTRAINT report_transaction_transactionid_fkey FOREIGN KEY (transactionid) REFERENCES public.transactions(transactionid);


--
-- TOC entry 4709 (class 2606 OID 25522)
-- Name: transactions transactions_categoryid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_categoryid_fkey FOREIGN KEY (categoryid) REFERENCES public.categories(categoryid) ON DELETE CASCADE;


--
-- TOC entry 4710 (class 2606 OID 25528)
-- Name: transactions transactions_userid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_userid_fkey FOREIGN KEY (userid) REFERENCES public.users(userid);


--
-- TOC entry 4877 (class 0 OID 0)
-- Dependencies: 5
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


-- Completed on 2025-04-22 05:49:39

--
-- PostgreSQL database dump complete
--

--
-- Database "homefinancedb" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

-- Started on 2025-04-22 05:49:39

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 4786 (class 1262 OID 25076)
-- Name: homefinancedb; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE homefinancedb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'ru-RU';


ALTER DATABASE homefinancedb OWNER TO postgres;

\connect homefinancedb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

-- Completed on 2025-04-22 05:49:39

--
-- PostgreSQL database dump complete
--

--
-- Database "polyclinic_db" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

-- Started on 2025-04-22 05:49:39

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 4899 (class 1262 OID 25255)
-- Name: polyclinic_db; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE polyclinic_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'ru-RU';


ALTER DATABASE polyclinic_db OWNER TO postgres;

\connect polyclinic_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 224 (class 1259 OID 25283)
-- Name: appointments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.appointments (
    appointmentid integer NOT NULL,
    patientid integer,
    doctorid integer,
    scheduleid integer,
    appointmentdate timestamp without time zone NOT NULL,
    status character varying(20) DEFAULT 'Запланирован'::character varying
);


ALTER TABLE public.appointments OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 25282)
-- Name: appointments_appointmentid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.appointments_appointmentid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.appointments_appointmentid_seq OWNER TO postgres;

--
-- TOC entry 4900 (class 0 OID 0)
-- Dependencies: 223
-- Name: appointments_appointmentid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.appointments_appointmentid_seq OWNED BY public.appointments.appointmentid;


--
-- TOC entry 234 (class 1259 OID 25353)
-- Name: bills; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bills (
    billid integer NOT NULL,
    patientid integer,
    serviceid integer,
    amount numeric(10,2) NOT NULL,
    billdate date NOT NULL,
    status character varying(20) DEFAULT 'Не оплачен'::character varying
);


ALTER TABLE public.bills OWNER TO postgres;

--
-- TOC entry 233 (class 1259 OID 25352)
-- Name: bills_billid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bills_billid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bills_billid_seq OWNER TO postgres;

--
-- TOC entry 4901 (class 0 OID 0)
-- Dependencies: 233
-- Name: bills_billid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bills_billid_seq OWNED BY public.bills.billid;


--
-- TOC entry 228 (class 1259 OID 25325)
-- Name: departments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.departments (
    departmentid integer NOT NULL,
    departmentname character varying(100) NOT NULL,
    location character varying(200)
);


ALTER TABLE public.departments OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 25324)
-- Name: departments_departmentid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.departments_departmentid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.departments_departmentid_seq OWNER TO postgres;

--
-- TOC entry 4902 (class 0 OID 0)
-- Dependencies: 227
-- Name: departments_departmentid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.departments_departmentid_seq OWNED BY public.departments.departmentid;


--
-- TOC entry 220 (class 1259 OID 25264)
-- Name: doctors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.doctors (
    doctorid integer NOT NULL,
    fullname character varying(100) NOT NULL,
    specialization character varying(100) NOT NULL,
    phone character varying(15),
    email character varying(100)
);


ALTER TABLE public.doctors OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 25263)
-- Name: doctors_doctorid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.doctors_doctorid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.doctors_doctorid_seq OWNER TO postgres;

--
-- TOC entry 4903 (class 0 OID 0)
-- Dependencies: 219
-- Name: doctors_doctorid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.doctors_doctorid_seq OWNED BY public.doctors.doctorid;


--
-- TOC entry 226 (class 1259 OID 25306)
-- Name: medicalrecords; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.medicalrecords (
    recordid integer NOT NULL,
    patientid integer,
    doctorid integer,
    diagnosis text,
    prescription text,
    testresults text,
    recorddate date NOT NULL
);


ALTER TABLE public.medicalrecords OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 25305)
-- Name: medicalrecords_recordid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.medicalrecords_recordid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.medicalrecords_recordid_seq OWNER TO postgres;

--
-- TOC entry 4904 (class 0 OID 0)
-- Dependencies: 225
-- Name: medicalrecords_recordid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.medicalrecords_recordid_seq OWNED BY public.medicalrecords.recordid;


--
-- TOC entry 218 (class 1259 OID 25257)
-- Name: patients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.patients (
    patientid integer NOT NULL,
    fullname character varying(100) NOT NULL,
    birthdate date NOT NULL,
    gender character varying(10) NOT NULL,
    address character varying(200),
    phone character varying(15),
    email character varying(100)
);


ALTER TABLE public.patients OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 25256)
-- Name: patients_patientid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.patients_patientid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.patients_patientid_seq OWNER TO postgres;

--
-- TOC entry 4905 (class 0 OID 0)
-- Dependencies: 217
-- Name: patients_patientid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.patients_patientid_seq OWNED BY public.patients.patientid;


--
-- TOC entry 230 (class 1259 OID 25332)
-- Name: rooms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rooms (
    roomid integer NOT NULL,
    departmentid integer,
    roomnumber character varying(20) NOT NULL
);


ALTER TABLE public.rooms OWNER TO postgres;

--
-- TOC entry 229 (class 1259 OID 25331)
-- Name: rooms_roomid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rooms_roomid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rooms_roomid_seq OWNER TO postgres;

--
-- TOC entry 4906 (class 0 OID 0)
-- Dependencies: 229
-- Name: rooms_roomid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rooms_roomid_seq OWNED BY public.rooms.roomid;


--
-- TOC entry 222 (class 1259 OID 25271)
-- Name: schedules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schedules (
    scheduleid integer NOT NULL,
    doctorid integer,
    date date NOT NULL,
    starttime time without time zone NOT NULL,
    endtime time without time zone NOT NULL
);


ALTER TABLE public.schedules OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 25270)
-- Name: schedules_scheduleid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.schedules_scheduleid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.schedules_scheduleid_seq OWNER TO postgres;

--
-- TOC entry 4907 (class 0 OID 0)
-- Dependencies: 221
-- Name: schedules_scheduleid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.schedules_scheduleid_seq OWNED BY public.schedules.scheduleid;


--
-- TOC entry 232 (class 1259 OID 25344)
-- Name: services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.services (
    serviceid integer NOT NULL,
    servicename character varying(100) NOT NULL,
    description text,
    cost numeric(10,2) NOT NULL
);


ALTER TABLE public.services OWNER TO postgres;

--
-- TOC entry 231 (class 1259 OID 25343)
-- Name: services_serviceid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.services_serviceid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.services_serviceid_seq OWNER TO postgres;

--
-- TOC entry 4908 (class 0 OID 0)
-- Dependencies: 231
-- Name: services_serviceid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.services_serviceid_seq OWNED BY public.services.serviceid;


--
-- TOC entry 236 (class 1259 OID 25371)
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    userid integer NOT NULL,
    username character varying(50) NOT NULL,
    passwordhash character varying(255) NOT NULL,
    role character varying(20) NOT NULL,
    fullname character varying(100),
    email character varying(100),
    phone character varying(20)
);


ALTER TABLE public.users OWNER TO postgres;

--
-- TOC entry 235 (class 1259 OID 25370)
-- Name: users_userid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_userid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_userid_seq OWNER TO postgres;

--
-- TOC entry 4909 (class 0 OID 0)
-- Dependencies: 235
-- Name: users_userid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_userid_seq OWNED BY public.users.userid;


--
-- TOC entry 4689 (class 2604 OID 25286)
-- Name: appointments appointmentid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments ALTER COLUMN appointmentid SET DEFAULT nextval('public.appointments_appointmentid_seq'::regclass);


--
-- TOC entry 4695 (class 2604 OID 25356)
-- Name: bills billid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bills ALTER COLUMN billid SET DEFAULT nextval('public.bills_billid_seq'::regclass);


--
-- TOC entry 4692 (class 2604 OID 25328)
-- Name: departments departmentid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departments ALTER COLUMN departmentid SET DEFAULT nextval('public.departments_departmentid_seq'::regclass);


--
-- TOC entry 4687 (class 2604 OID 25267)
-- Name: doctors doctorid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctors ALTER COLUMN doctorid SET DEFAULT nextval('public.doctors_doctorid_seq'::regclass);


--
-- TOC entry 4691 (class 2604 OID 25309)
-- Name: medicalrecords recordid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medicalrecords ALTER COLUMN recordid SET DEFAULT nextval('public.medicalrecords_recordid_seq'::regclass);


--
-- TOC entry 4686 (class 2604 OID 25260)
-- Name: patients patientid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patients ALTER COLUMN patientid SET DEFAULT nextval('public.patients_patientid_seq'::regclass);


--
-- TOC entry 4693 (class 2604 OID 25335)
-- Name: rooms roomid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rooms ALTER COLUMN roomid SET DEFAULT nextval('public.rooms_roomid_seq'::regclass);


--
-- TOC entry 4688 (class 2604 OID 25274)
-- Name: schedules scheduleid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedules ALTER COLUMN scheduleid SET DEFAULT nextval('public.schedules_scheduleid_seq'::regclass);


--
-- TOC entry 4694 (class 2604 OID 25347)
-- Name: services serviceid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services ALTER COLUMN serviceid SET DEFAULT nextval('public.services_serviceid_seq'::regclass);


--
-- TOC entry 4697 (class 2604 OID 25374)
-- Name: users userid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN userid SET DEFAULT nextval('public.users_userid_seq'::regclass);


--
-- TOC entry 4881 (class 0 OID 25283)
-- Dependencies: 224
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.appointments (appointmentid, patientid, doctorid, scheduleid, appointmentdate, status) FROM stdin;
2	2	2	2	2023-10-25 10:30:00	Запланирован
3	3	3	3	2023-10-25 11:30:00	Запланирован
4	4	4	4	2023-10-25 12:30:00	Запланирован
5	1	1	5	2025-03-22 20:30:00	Запланирован
6	2	2	\N	2025-03-22 20:31:00	Запланирован
\.


--
-- TOC entry 4891 (class 0 OID 25353)
-- Dependencies: 234
-- Data for Name: bills; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bills (billid, patientid, serviceid, amount, billdate, status) FROM stdin;
1	1	1	1500.00	2023-10-20	Оплачен
2	2	2	50000.00	2023-10-21	Не оплачен
3	3	3	2000.00	2023-10-22	Оплачен
4	4	4	2500.00	2023-10-23	Не оплачен
5	5	5	3000.00	2023-10-24	Оплачен
\.


--
-- TOC entry 4885 (class 0 OID 25325)
-- Dependencies: 228
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.departments (departmentid, departmentname, location) FROM stdin;
1	Терапевтическое отделение	1 этаж, кабинет 101
2	Хирургическое отделение	2 этаж, кабинет 201
3	Кардиологическое отделение	3 этаж, кабинет 301
4	Офтальмологическое отделение	4 этаж, кабинет 401
5	Неврологическое отделение	5 этаж, кабинет 501
\.


--
-- TOC entry 4877 (class 0 OID 25264)
-- Dependencies: 220
-- Data for Name: doctors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.doctors (doctorid, fullname, specialization, phone, email) FROM stdin;
1	Смирнов Александр Петрович	Терапевт	+79101112233	smirnov@clinic.ru
2	Ковалева Ольга Ивановна	Хирург	+79102223344	kovaleva@clinic.ru
3	Белов Павел Сергеевич	Кардиолог	+79103334455	belov@clinic.ru
4	Григорьева Марина Викторовна	Офтальмолог	+79104445566	grigoreva@clinic.ru
5	Игнатьев Игорь Дмитриевич	Невролог	+79105556677	ignatiev@clinic.ru
\.


--
-- TOC entry 4883 (class 0 OID 25306)
-- Dependencies: 226
-- Data for Name: medicalrecords; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.medicalrecords (recordid, patientid, doctorid, diagnosis, prescription, testresults, recorddate) FROM stdin;
1	1	1	ОРВИ	Постельный режим, обильное питье	Анализы в норме	2023-10-20
2	2	2	Аппендицит	Операция	Анализы в норме	2023-10-21
3	3	3	Гипертония	Прием лекарств	Анализы в норме	2023-10-22
4	4	4	Катаракта	Операция	Анализы в норме	2023-10-23
5	5	5	Мигрень	Прием лекарств	Анализы в норме	2023-10-24
\.


--
-- TOC entry 4875 (class 0 OID 25257)
-- Dependencies: 218
-- Data for Name: patients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.patients (patientid, fullname, birthdate, gender, address, phone, email) FROM stdin;
1	Иванов Иван Иванович	1985-05-15	Мужской	ул. Ленина, 10	+79101234567	ivanov@mail.ru
2	Петрова Анна Сергеевна	1990-12-22	Женский	ул. Пушкина, 5	+79107654321	petrova@gmail.com
3	Сидоров Алексей Викторович	1978-03-30	Мужской	ул. Гагарина, 15	+79105554433	sidorov@yandex.ru
4	Козлова Елена Дмитриевна	1982-07-10	Женский	ул. Мира, 20	+79106667788	kozlova@mail.ru
5	Морозов Дмитрий Алексеевич	1995-11-25	Мужской	ул. Садовая, 30	+79108889900	morozov@gmail.com
\.


--
-- TOC entry 4887 (class 0 OID 25332)
-- Dependencies: 230
-- Data for Name: rooms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rooms (roomid, departmentid, roomnumber) FROM stdin;
1	1	101
2	2	201
3	3	301
4	4	401
5	5	501
\.


--
-- TOC entry 4879 (class 0 OID 25271)
-- Dependencies: 222
-- Data for Name: schedules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schedules (scheduleid, doctorid, date, starttime, endtime) FROM stdin;
1	1	2023-10-25	09:00:00	13:00:00
2	2	2023-10-25	10:00:00	14:00:00
3	3	2023-10-25	11:00:00	15:00:00
4	4	2023-10-25	12:00:00	16:00:00
5	5	2023-10-25	13:00:00	17:00:00
\.


--
-- TOC entry 4889 (class 0 OID 25344)
-- Dependencies: 232
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.services (serviceid, servicename, description, cost) FROM stdin;
1	Консультация терапевта	Первичный прием терапевта	1500.00
2	Операция аппендицита	Хирургическое вмешательство	50000.00
3	ЭКГ	Электрокардиограмма	2000.00
4	Осмотр офтальмолога	Проверка зрения	2500.00
5	Консультация невролога	Первичный прием невролога	3000.00
\.


--
-- TOC entry 4893 (class 0 OID 25371)
-- Dependencies: 236
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (userid, username, passwordhash, role, fullname, email, phone) FROM stdin;
1	admin	hashed_password_1	Админ	\N	\N	\N
2	doctor1	hashed_password_2	Врач	\N	\N	\N
3	doctor2	hashed_password_3	Врач	\N	\N	\N
4	patient1	hashed_password_4	Пациент	\N	\N	\N
5	patient2	hashed_password_5	Пациент	\N	\N	\N
7	admin1	$2b$10$diKuM76WmQDja6bhQ9B31OSQz3cAGjlerFGyksJn8lnyMJ4QViklO	admin	Петров Петр Петрович	admin@gmail.com	+7 (950) 567-68-36
\.


--
-- TOC entry 4910 (class 0 OID 0)
-- Dependencies: 223
-- Name: appointments_appointmentid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.appointments_appointmentid_seq', 6, true);


--
-- TOC entry 4911 (class 0 OID 0)
-- Dependencies: 233
-- Name: bills_billid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bills_billid_seq', 5, true);


--
-- TOC entry 4912 (class 0 OID 0)
-- Dependencies: 227
-- Name: departments_departmentid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.departments_departmentid_seq', 5, true);


--
-- TOC entry 4913 (class 0 OID 0)
-- Dependencies: 219
-- Name: doctors_doctorid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.doctors_doctorid_seq', 5, true);


--
-- TOC entry 4914 (class 0 OID 0)
-- Dependencies: 225
-- Name: medicalrecords_recordid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.medicalrecords_recordid_seq', 5, true);


--
-- TOC entry 4915 (class 0 OID 0)
-- Dependencies: 217
-- Name: patients_patientid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.patients_patientid_seq', 5, true);


--
-- TOC entry 4916 (class 0 OID 0)
-- Dependencies: 229
-- Name: rooms_roomid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rooms_roomid_seq', 5, true);


--
-- TOC entry 4917 (class 0 OID 0)
-- Dependencies: 221
-- Name: schedules_scheduleid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.schedules_scheduleid_seq', 5, true);


--
-- TOC entry 4918 (class 0 OID 0)
-- Dependencies: 231
-- Name: services_serviceid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.services_serviceid_seq', 5, true);


--
-- TOC entry 4919 (class 0 OID 0)
-- Dependencies: 235
-- Name: users_userid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_userid_seq', 7, true);


--
-- TOC entry 4705 (class 2606 OID 25289)
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (appointmentid);


--
-- TOC entry 4715 (class 2606 OID 25359)
-- Name: bills bills_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bills
    ADD CONSTRAINT bills_pkey PRIMARY KEY (billid);


--
-- TOC entry 4709 (class 2606 OID 25330)
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (departmentid);


--
-- TOC entry 4701 (class 2606 OID 25269)
-- Name: doctors doctors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctors
    ADD CONSTRAINT doctors_pkey PRIMARY KEY (doctorid);


--
-- TOC entry 4707 (class 2606 OID 25313)
-- Name: medicalrecords medicalrecords_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medicalrecords
    ADD CONSTRAINT medicalrecords_pkey PRIMARY KEY (recordid);


--
-- TOC entry 4699 (class 2606 OID 25262)
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (patientid);


--
-- TOC entry 4711 (class 2606 OID 25337)
-- Name: rooms rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_pkey PRIMARY KEY (roomid);


--
-- TOC entry 4703 (class 2606 OID 25276)
-- Name: schedules schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedules
    ADD CONSTRAINT schedules_pkey PRIMARY KEY (scheduleid);


--
-- TOC entry 4713 (class 2606 OID 25351)
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (serviceid);


--
-- TOC entry 4717 (class 2606 OID 25376)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (userid);


--
-- TOC entry 4719 (class 2606 OID 25378)
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- TOC entry 4721 (class 2606 OID 25295)
-- Name: appointments appointments_doctorid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_doctorid_fkey FOREIGN KEY (doctorid) REFERENCES public.doctors(doctorid);


--
-- TOC entry 4722 (class 2606 OID 25290)
-- Name: appointments appointments_patientid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_patientid_fkey FOREIGN KEY (patientid) REFERENCES public.patients(patientid);


--
-- TOC entry 4723 (class 2606 OID 25300)
-- Name: appointments appointments_scheduleid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_scheduleid_fkey FOREIGN KEY (scheduleid) REFERENCES public.schedules(scheduleid);


--
-- TOC entry 4727 (class 2606 OID 25360)
-- Name: bills bills_patientid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bills
    ADD CONSTRAINT bills_patientid_fkey FOREIGN KEY (patientid) REFERENCES public.patients(patientid);


--
-- TOC entry 4728 (class 2606 OID 25365)
-- Name: bills bills_serviceid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bills
    ADD CONSTRAINT bills_serviceid_fkey FOREIGN KEY (serviceid) REFERENCES public.services(serviceid);


--
-- TOC entry 4724 (class 2606 OID 25319)
-- Name: medicalrecords medicalrecords_doctorid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medicalrecords
    ADD CONSTRAINT medicalrecords_doctorid_fkey FOREIGN KEY (doctorid) REFERENCES public.doctors(doctorid);


--
-- TOC entry 4725 (class 2606 OID 25314)
-- Name: medicalrecords medicalrecords_patientid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medicalrecords
    ADD CONSTRAINT medicalrecords_patientid_fkey FOREIGN KEY (patientid) REFERENCES public.patients(patientid);


--
-- TOC entry 4726 (class 2606 OID 25338)
-- Name: rooms rooms_departmentid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_departmentid_fkey FOREIGN KEY (departmentid) REFERENCES public.departments(departmentid);


--
-- TOC entry 4720 (class 2606 OID 25277)
-- Name: schedules schedules_doctorid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedules
    ADD CONSTRAINT schedules_doctorid_fkey FOREIGN KEY (doctorid) REFERENCES public.doctors(doctorid);


-- Completed on 2025-04-22 05:49:39

--
-- PostgreSQL database dump complete
--

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

-- Started on 2025-04-22 05:49:39

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

-- Completed on 2025-04-22 05:49:39

--
-- PostgreSQL database dump complete
--

--
-- Database "real_estate_agency" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

-- Started on 2025-04-22 05:49:39

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 4843 (class 1262 OID 24863)
-- Name: real_estate_agency; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE real_estate_agency WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'ru-RU';


ALTER DATABASE real_estate_agency OWNER TO postgres;

\connect real_estate_agency

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 218 (class 1259 OID 24865)
-- Name: clients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clients (
    client_id integer NOT NULL,
    first_name character varying(50),
    last_name character varying(50),
    phone character varying(15),
    email character varying(100)
);


ALTER TABLE public.clients OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 24864)
-- Name: clients_client_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.clients_client_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.clients_client_id_seq OWNER TO postgres;

--
-- TOC entry 4844 (class 0 OID 0)
-- Dependencies: 217
-- Name: clients_client_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.clients_client_id_seq OWNED BY public.clients.client_id;


--
-- TOC entry 222 (class 1259 OID 24879)
-- Name: properties; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.properties (
    property_id integer NOT NULL,
    address character varying(255),
    price numeric(10,2),
    property_type character varying(50),
    size numeric(10,2),
    realtor_id integer,
    description text
);


ALTER TABLE public.properties OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 24878)
-- Name: properties_property_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.properties_property_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.properties_property_id_seq OWNER TO postgres;

--
-- TOC entry 4845 (class 0 OID 0)
-- Dependencies: 221
-- Name: properties_property_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.properties_property_id_seq OWNED BY public.properties.property_id;


--
-- TOC entry 220 (class 1259 OID 24872)
-- Name: realtors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.realtors (
    realtor_id integer NOT NULL,
    first_name character varying(50),
    last_name character varying(50),
    phone character varying(15),
    email character varying(100),
    hire_date date
);


ALTER TABLE public.realtors OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 24871)
-- Name: realtors_realtor_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.realtors_realtor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.realtors_realtor_id_seq OWNER TO postgres;

--
-- TOC entry 4846 (class 0 OID 0)
-- Dependencies: 219
-- Name: realtors_realtor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.realtors_realtor_id_seq OWNED BY public.realtors.realtor_id;


--
-- TOC entry 224 (class 1259 OID 24891)
-- Name: transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transactions (
    transaction_id integer NOT NULL,
    property_id integer,
    client_id integer,
    realtor_id integer,
    transaction_date date,
    transaction_amount numeric(10,2),
    date date,
    amount numeric(10,2)
);


ALTER TABLE public.transactions OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 24890)
-- Name: transactions_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.transactions_transaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.transactions_transaction_id_seq OWNER TO postgres;

--
-- TOC entry 4847 (class 0 OID 0)
-- Dependencies: 223
-- Name: transactions_transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.transactions_transaction_id_seq OWNED BY public.transactions.transaction_id;


--
-- TOC entry 226 (class 1259 OID 24914)
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50),
    password character varying(255),
    role character varying(50) DEFAULT 'user'::character varying
);


ALTER TABLE public.users OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 24913)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- TOC entry 4848 (class 0 OID 0)
-- Dependencies: 225
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- TOC entry 4661 (class 2604 OID 24868)
-- Name: clients client_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients ALTER COLUMN client_id SET DEFAULT nextval('public.clients_client_id_seq'::regclass);


--
-- TOC entry 4663 (class 2604 OID 24882)
-- Name: properties property_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.properties ALTER COLUMN property_id SET DEFAULT nextval('public.properties_property_id_seq'::regclass);


--
-- TOC entry 4662 (class 2604 OID 24875)
-- Name: realtors realtor_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.realtors ALTER COLUMN realtor_id SET DEFAULT nextval('public.realtors_realtor_id_seq'::regclass);


--
-- TOC entry 4664 (class 2604 OID 24894)
-- Name: transactions transaction_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions ALTER COLUMN transaction_id SET DEFAULT nextval('public.transactions_transaction_id_seq'::regclass);


--
-- TOC entry 4665 (class 2604 OID 24917)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- TOC entry 4829 (class 0 OID 24865)
-- Dependencies: 218
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clients (client_id, first_name, last_name, phone, email) FROM stdin;
1	Иван	Иванов	1234567890	ivan@example.com
2	Петр	Петров	0987654321	petr@example.com
3	Светлана	Сидорова	5556667777	svetlana@example.com
4	Алексей	Алексеев	4445556666	alexey@example.com
5	Мария	Маркова	3334445555	maria@example.com
6	Дмитрий	Дмитриев	2223334444	dmitry@example.com
7	Елена	Еленина	1112223333	elena@example.com
8	Николай	Николаев	8889990000	nikolai@example.com
9	Ольга	Ольгина	7778889999	olga@example.com
10	Сергей	Сергеев	6667778888	sergey@example.com
\.


--
-- TOC entry 4833 (class 0 OID 24879)
-- Dependencies: 222
-- Data for Name: properties; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.properties (property_id, address, price, property_type, size, realtor_id, description) FROM stdin;
1	Улица Ленина, 1	5000000.00	Квартира	75.00	1	\N
2	Улица Пушкина, 2	3000000.00	Дом	150.00	2	\N
3	Улица Гагарина, 3	4500000.00	Квартира	80.00	1	\N
4	Улица Чехова, 4	6000000.00	Коммерческая	200.00	3	\N
5	Улица Мира, 5	3500000.00	Квартира	70.00	2	\N
6	Улица Крылатская, 6	7000000.00	Дом	250.00	4	\N
7	Улица Солнечная, 7	4000000.00	Квартира	90.00	5	\N
8	Улица Набережная, 8	8000000.00	Коммерческая	300.00	6	\N
9	Улица Лесная, 9	5500000.00	Квартира	85.00	7	\N
10	Улица Озерная, 10	7500000.00	Дом	220.00	8	\N
11	Улица Темирязева, 1	32000000.00	\N	\N	2	212312
\.


--
-- TOC entry 4831 (class 0 OID 24872)
-- Dependencies: 220
-- Data for Name: realtors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.realtors (realtor_id, first_name, last_name, phone, email, hire_date) FROM stdin;
1	Анна	Сидорова	1112223333	anna@example.com	2023-01-15
2	Сергей	Кузнецов	4445556666	sergey@example.com	2023-02-20
3	Марина	Петрова	3334445555	marina@example.com	2023-03-10
4	Александр	Смирнов	2223334444	alexander@example.com	2023-04-05
5	Екатерина	Федорова	5556667777	ekaterina@example.com	2023-05-12
6	Дмитрий	Соловьев	8889990000	dmitry@example.com	2023-06-01
7	Татьяна	Коваленко	7778889999	tatiana@example.com	2023-07-15
8	Игорь	Григорьев	6667778888	igor@example.com	2023-08-20
9	Анастасия	Лебедева	9990001111	anastasia@example.com	2023-09-10
11	Петров	Петрович	123123123123	petrov@mail.ru	\N
13	1	1	1	1@23.RU	1212-12-12
14	1	1	1	1@23.RU	1212-12-12
\.


--
-- TOC entry 4835 (class 0 OID 24891)
-- Dependencies: 224
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transactions (transaction_id, property_id, client_id, realtor_id, transaction_date, transaction_amount, date, amount) FROM stdin;
1	1	1	1	2023-03-01	4800000.00	\N	\N
2	2	2	2	2023-04-15	2900000.00	\N	\N
3	3	3	1	2023-05-20	4300000.00	\N	\N
4	4	4	3	2023-06-10	5800000.00	\N	\N
5	5	5	2	2023-07-25	3400000.00	\N	\N
6	6	6	4	2023-08-30	6900000.00	\N	\N
7	7	7	5	2023-09-15	3900000.00	\N	\N
8	8	8	6	2023-10-05	7800000.00	\N	\N
9	9	9	7	2023-11-01	5200000.00	\N	\N
11	1	1	\N	\N	\N	2005-12-12	123123.00
\.


--
-- TOC entry 4837 (class 0 OID 24914)
-- Dependencies: 226
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, password, role) FROM stdin;
4	admin	$2b$10$MzkFCr.64ViTRgjYz/PJDO7e/SiQqc3ZODwbrVS9G4yJWXGjgJHva	admin
5	user	$2b$10$xheSkMfOUjz8tyfyjbkZqeSxJqnHRhoXzKFADPAuX0PsQystW873a	user
\.


--
-- TOC entry 4849 (class 0 OID 0)
-- Dependencies: 217
-- Name: clients_client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.clients_client_id_seq', 15, true);


--
-- TOC entry 4850 (class 0 OID 0)
-- Dependencies: 221
-- Name: properties_property_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.properties_property_id_seq', 11, true);


--
-- TOC entry 4851 (class 0 OID 0)
-- Dependencies: 219
-- Name: realtors_realtor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.realtors_realtor_id_seq', 14, true);


--
-- TOC entry 4852 (class 0 OID 0)
-- Dependencies: 223
-- Name: transactions_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.transactions_transaction_id_seq', 11, true);


--
-- TOC entry 4853 (class 0 OID 0)
-- Dependencies: 225
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 5, true);


--
-- TOC entry 4668 (class 2606 OID 24870)
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (client_id);


--
-- TOC entry 4672 (class 2606 OID 24884)
-- Name: properties properties_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_pkey PRIMARY KEY (property_id);


--
-- TOC entry 4670 (class 2606 OID 24877)
-- Name: realtors realtors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.realtors
    ADD CONSTRAINT realtors_pkey PRIMARY KEY (realtor_id);


--
-- TOC entry 4674 (class 2606 OID 24896)
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (transaction_id);


--
-- TOC entry 4676 (class 2606 OID 24919)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 4678 (class 2606 OID 24921)
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- TOC entry 4679 (class 2606 OID 24885)
-- Name: properties properties_realtor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_realtor_id_fkey FOREIGN KEY (realtor_id) REFERENCES public.realtors(realtor_id);


--
-- TOC entry 4680 (class 2606 OID 24902)
-- Name: transactions transactions_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(client_id);


--
-- TOC entry 4681 (class 2606 OID 24897)
-- Name: transactions transactions_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(property_id);


--
-- TOC entry 4682 (class 2606 OID 24907)
-- Name: transactions transactions_realtor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_realtor_id_fkey FOREIGN KEY (realtor_id) REFERENCES public.realtors(realtor_id);


-- Completed on 2025-04-22 05:49:40

--
-- PostgreSQL database dump complete
--

--
-- Database "ssud" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

-- Started on 2025-04-22 05:49:40

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 4832 (class 1262 OID 16388)
-- Name: ssud; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE ssud WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'ru-RU';


ALTER DATABASE ssud OWNER TO postgres;

\connect ssud

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 222 (class 1259 OID 16405)
-- Name: grades; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.grades (
    id integer NOT NULL,
    student_id integer NOT NULL,
    subject_id integer NOT NULL,
    grade numeric(3,2) NOT NULL,
    dateofgrade date NOT NULL
);


ALTER TABLE public.grades OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 16404)
-- Name: grades_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.grades_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.grades_id_seq OWNER TO postgres;

--
-- TOC entry 4833 (class 0 OID 0)
-- Dependencies: 221
-- Name: grades_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.grades_id_seq OWNED BY public.grades.id;


--
-- TOC entry 224 (class 1259 OID 16422)
-- Name: scholarships; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.scholarships (
    id integer NOT NULL,
    student_id integer NOT NULL,
    type character varying(50) NOT NULL,
    amount numeric(10,2) NOT NULL,
    conditions text
);


ALTER TABLE public.scholarships OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 16421)
-- Name: scholarships_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.scholarships_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.scholarships_id_seq OWNER TO postgres;

--
-- TOC entry 4834 (class 0 OID 0)
-- Dependencies: 223
-- Name: scholarships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.scholarships_id_seq OWNED BY public.scholarships.id;


--
-- TOC entry 218 (class 1259 OID 16391)
-- Name: students; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.students (
    id integer NOT NULL,
    fullname character varying(100) NOT NULL,
    groupname character varying(50) NOT NULL,
    specialty character varying(100) NOT NULL,
    dateofbirth date NOT NULL,
    dateofadmission date NOT NULL,
    contactinfo character varying(100)
);


ALTER TABLE public.students OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 16390)
-- Name: students_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.students_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.students_id_seq OWNER TO postgres;

--
-- TOC entry 4835 (class 0 OID 0)
-- Dependencies: 217
-- Name: students_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.students_id_seq OWNED BY public.students.id;


--
-- TOC entry 220 (class 1259 OID 16398)
-- Name: subjects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subjects (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    credits integer NOT NULL,
    teacher character varying(100) NOT NULL,
    semester integer NOT NULL
);


ALTER TABLE public.subjects OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 16397)
-- Name: subjects_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.subjects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.subjects_id_seq OWNER TO postgres;

--
-- TOC entry 4836 (class 0 OID 0)
-- Dependencies: 219
-- Name: subjects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.subjects_id_seq OWNED BY public.subjects.id;


--
-- TOC entry 4658 (class 2604 OID 16408)
-- Name: grades id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grades ALTER COLUMN id SET DEFAULT nextval('public.grades_id_seq'::regclass);


--
-- TOC entry 4659 (class 2604 OID 16425)
-- Name: scholarships id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scholarships ALTER COLUMN id SET DEFAULT nextval('public.scholarships_id_seq'::regclass);


--
-- TOC entry 4656 (class 2604 OID 16394)
-- Name: students id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students ALTER COLUMN id SET DEFAULT nextval('public.students_id_seq'::regclass);


--
-- TOC entry 4657 (class 2604 OID 16401)
-- Name: subjects id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subjects ALTER COLUMN id SET DEFAULT nextval('public.subjects_id_seq'::regclass);


--
-- TOC entry 4824 (class 0 OID 16405)
-- Dependencies: 222
-- Data for Name: grades; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.grades (id, student_id, subject_id, grade, dateofgrade) FROM stdin;
\.


--
-- TOC entry 4826 (class 0 OID 16422)
-- Dependencies: 224
-- Data for Name: scholarships; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.scholarships (id, student_id, type, amount, conditions) FROM stdin;
\.


--
-- TOC entry 4820 (class 0 OID 16391)
-- Dependencies: 218
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.students (id, fullname, groupname, specialty, dateofbirth, dateofadmission, contactinfo) FROM stdin;
\.


--
-- TOC entry 4822 (class 0 OID 16398)
-- Dependencies: 220
-- Data for Name: subjects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subjects (id, name, credits, teacher, semester) FROM stdin;
\.


--
-- TOC entry 4837 (class 0 OID 0)
-- Dependencies: 221
-- Name: grades_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.grades_id_seq', 1, false);


--
-- TOC entry 4838 (class 0 OID 0)
-- Dependencies: 223
-- Name: scholarships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.scholarships_id_seq', 1, false);


--
-- TOC entry 4839 (class 0 OID 0)
-- Dependencies: 217
-- Name: students_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.students_id_seq', 1, false);


--
-- TOC entry 4840 (class 0 OID 0)
-- Dependencies: 219
-- Name: subjects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.subjects_id_seq', 1, false);


--
-- TOC entry 4665 (class 2606 OID 16410)
-- Name: grades grades_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_pkey PRIMARY KEY (id);


--
-- TOC entry 4670 (class 2606 OID 16429)
-- Name: scholarships scholarships_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scholarships
    ADD CONSTRAINT scholarships_pkey PRIMARY KEY (id);


--
-- TOC entry 4661 (class 2606 OID 16396)
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- TOC entry 4663 (class 2606 OID 16403)
-- Name: subjects subjects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT subjects_pkey PRIMARY KEY (id);


--
-- TOC entry 4668 (class 1259 OID 16437)
-- Name: idx_scholarship_student; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scholarship_student ON public.scholarships USING btree (student_id);


--
-- TOC entry 4666 (class 1259 OID 16435)
-- Name: idx_student; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_student ON public.grades USING btree (student_id);


--
-- TOC entry 4667 (class 1259 OID 16436)
-- Name: idx_subject; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_subject ON public.grades USING btree (subject_id);


--
-- TOC entry 4671 (class 2606 OID 16411)
-- Name: grades grades_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id);


--
-- TOC entry 4672 (class 2606 OID 16416)
-- Name: grades grades_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.subjects(id);


--
-- TOC entry 4673 (class 2606 OID 16430)
-- Name: scholarships scholarships_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scholarships
    ADD CONSTRAINT scholarships_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id);


-- Completed on 2025-04-22 05:49:40

--
-- PostgreSQL database dump complete
--

--
-- Database "stipend_db" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

-- Started on 2025-04-22 05:49:40

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 4886 (class 1262 OID 16389)
-- Name: stipend_db; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE stipend_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'ru-RU';


ALTER DATABASE stipend_db OWNER TO postgres;

\connect stipend_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 222 (class 1259 OID 16453)
-- Name: grades; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.grades (
    id integer NOT NULL,
    student_id integer NOT NULL,
    subject_id integer NOT NULL,
    grade numeric(3,2) NOT NULL,
    dateofgrade date NOT NULL
);


ALTER TABLE public.grades OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 16452)
-- Name: grades_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.grades_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.grades_id_seq OWNER TO postgres;

--
-- TOC entry 4887 (class 0 OID 0)
-- Dependencies: 221
-- Name: grades_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.grades_id_seq OWNED BY public.grades.id;


--
-- TOC entry 226 (class 1259 OID 24586)
-- Name: news; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.news (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    image character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.news OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 24585)
-- Name: news_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.news_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.news_id_seq OWNER TO postgres;

--
-- TOC entry 4888 (class 0 OID 0)
-- Dependencies: 225
-- Name: news_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.news_id_seq OWNED BY public.news.id;


--
-- TOC entry 230 (class 1259 OID 25396)
-- Name: reports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reports (
    id integer NOT NULL,
    student_id integer,
    subject_id integer,
    report text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.reports OWNER TO postgres;

--
-- TOC entry 229 (class 1259 OID 25395)
-- Name: reports_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reports_id_seq OWNER TO postgres;

--
-- TOC entry 4889 (class 0 OID 0)
-- Dependencies: 229
-- Name: reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reports_id_seq OWNED BY public.reports.id;


--
-- TOC entry 224 (class 1259 OID 16470)
-- Name: scholarships; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.scholarships (
    id integer NOT NULL,
    student_id integer NOT NULL,
    type character varying(50) NOT NULL,
    amount numeric(10,2) NOT NULL,
    conditions text
);


ALTER TABLE public.scholarships OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 16469)
-- Name: scholarships_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.scholarships_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.scholarships_id_seq OWNER TO postgres;

--
-- TOC entry 4890 (class 0 OID 0)
-- Dependencies: 223
-- Name: scholarships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.scholarships_id_seq OWNED BY public.scholarships.id;


--
-- TOC entry 218 (class 1259 OID 16439)
-- Name: students; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.students (
    id integer NOT NULL,
    fullname character varying(100) NOT NULL,
    groupname character varying(50) NOT NULL,
    specialty character varying(100) NOT NULL,
    dateofbirth date NOT NULL,
    dateofadmission date NOT NULL,
    contactinfo character varying(100)
);


ALTER TABLE public.students OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 16438)
-- Name: students_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.students_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.students_id_seq OWNER TO postgres;

--
-- TOC entry 4891 (class 0 OID 0)
-- Dependencies: 217
-- Name: students_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.students_id_seq OWNED BY public.students.id;


--
-- TOC entry 220 (class 1259 OID 16446)
-- Name: subjects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subjects (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    semester integer NOT NULL,
    teacher_id integer,
    teacher character varying(255)
);


ALTER TABLE public.subjects OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 16445)
-- Name: subjects_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.subjects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.subjects_id_seq OWNER TO postgres;

--
-- TOC entry 4892 (class 0 OID 0)
-- Dependencies: 219
-- Name: subjects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.subjects_id_seq OWNED BY public.subjects.id;


--
-- TOC entry 228 (class 1259 OID 25382)
-- Name: teachers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.teachers (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.teachers OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 25381)
-- Name: teachers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.teachers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.teachers_id_seq OWNER TO postgres;

--
-- TOC entry 4893 (class 0 OID 0)
-- Dependencies: 227
-- Name: teachers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.teachers_id_seq OWNED BY public.teachers.id;


--
-- TOC entry 232 (class 1259 OID 25423)
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    userid integer NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255),
    password character varying(255) NOT NULL,
    registrationdate timestamp without time zone DEFAULT now(),
    lastlogin timestamp without time zone,
    role character varying(50) DEFAULT 'user'::character varying,
    username text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    first_name text,
    last_name text,
    patronymic text,
    snils text,
    inn text,
    passport text
);


ALTER TABLE public.users OWNER TO postgres;

--
-- TOC entry 231 (class 1259 OID 25422)
-- Name: users_userid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_userid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_userid_seq OWNER TO postgres;

--
-- TOC entry 4894 (class 0 OID 0)
-- Dependencies: 231
-- Name: users_userid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_userid_seq OWNED BY public.users.userid;


--
-- TOC entry 4678 (class 2604 OID 16456)
-- Name: grades id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grades ALTER COLUMN id SET DEFAULT nextval('public.grades_id_seq'::regclass);


--
-- TOC entry 4680 (class 2604 OID 24589)
-- Name: news id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.news ALTER COLUMN id SET DEFAULT nextval('public.news_id_seq'::regclass);


--
-- TOC entry 4684 (class 2604 OID 25399)
-- Name: reports id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports ALTER COLUMN id SET DEFAULT nextval('public.reports_id_seq'::regclass);


--
-- TOC entry 4679 (class 2604 OID 16473)
-- Name: scholarships id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scholarships ALTER COLUMN id SET DEFAULT nextval('public.scholarships_id_seq'::regclass);


--
-- TOC entry 4676 (class 2604 OID 16442)
-- Name: students id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students ALTER COLUMN id SET DEFAULT nextval('public.students_id_seq'::regclass);


--
-- TOC entry 4677 (class 2604 OID 16449)
-- Name: subjects id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subjects ALTER COLUMN id SET DEFAULT nextval('public.subjects_id_seq'::regclass);


--
-- TOC entry 4682 (class 2604 OID 25385)
-- Name: teachers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teachers ALTER COLUMN id SET DEFAULT nextval('public.teachers_id_seq'::regclass);


--
-- TOC entry 4686 (class 2604 OID 25426)
-- Name: users userid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN userid SET DEFAULT nextval('public.users_userid_seq'::regclass);


--
-- TOC entry 4870 (class 0 OID 16453)
-- Dependencies: 222
-- Data for Name: grades; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.grades (id, student_id, subject_id, grade, dateofgrade) FROM stdin;
7	4	3	3.00	2023-01-15
8	4	4	4.00	2023-02-20
9	5	5	4.00	2023-01-15
10	5	6	3.50	2023-02-20
11	6	5	5.00	2023-01-15
12	6	6	4.00	2023-02-20
13	7	7	4.50	2023-01-15
14	7	8	5.00	2023-02-20
15	8	7	3.50	2023-01-15
16	8	8	4.00	2023-02-20
3	5	5	4.00	2023-01-15
18	4	2	4.00	2025-03-22
4	2	2	4.00	2023-02-20
19	4	2	5.00	2025-03-04
6	4	2	4.00	2005-02-21
\.


--
-- TOC entry 4874 (class 0 OID 24586)
-- Dependencies: 226
-- Data for Name: news; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.news (id, title, content, image, created_at) FROM stdin;
\.


--
-- TOC entry 4878 (class 0 OID 25396)
-- Dependencies: 230
-- Data for Name: reports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reports (id, student_id, subject_id, report, created_at) FROM stdin;
\.


--
-- TOC entry 4872 (class 0 OID 16470)
-- Dependencies: 224
-- Data for Name: scholarships; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.scholarships (id, student_id, type, amount, conditions) FROM stdin;
2	2	Социальная	3000.00	Наличие социальной необходимости
3	3	Академическая	6000.00	Минимальная оценка 4.5 по всем предметам
4	4	Социальная	2500.00	Наличие социальной необходимости
5	5	Академическая	5500.00	Минимальная оценка 4.0 по всем предметам
6	6	Социальная	4000.00	Наличие социальной необходимости
7	7	Академическая	7000.00	Минимальная оценка 4.5 по всем предметам
8	8	Социальная	3500.00	Наличие социальной необходимости
\.


--
-- TOC entry 4866 (class 0 OID 16439)
-- Dependencies: 218
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.students (id, fullname, groupname, specialty, dateofbirth, dateofadmission, contactinfo) FROM stdin;
4	Кузнецов Алексей Викторович	Группа 2	Дизайн	2000-04-25	2021-09-01	kuznetsov@mail.com
5	Смирнова Ольга Николаевна	Группа 3	Экономика	2001-05-30	2022-09-01	smirnova@mail.com
6	Федоров Сергей Александрович	Группа 3	Экономика	2000-06-15	2022-09-01	fedorov@mail.com
7	Морозова Екатерина Андреевна	Группа 4	Менеджмент	2001-07-20	2023-09-01	morozova@mail.com
8	Григорьев Дмитрий Владимирович	Группа 4	Менеджмент	2000-08-05	2023-09-01	grigoryev@mail.com
2	Петров Петр Петрович	Группа 2	Программирование	2000-02-19	2020-08-31	petrov@mail.com
3	Сидорова Анна Сергеевна	Группа 2	Дизайн	2001-03-09	2021-08-31	sidorov1a@mail.com
9	Сидорова Анна Сергеевна	Группа 4	Дизайн	2005-02-20	2022-10-20	sidoroVA@mail.com
\.


--
-- TOC entry 4868 (class 0 OID 16446)
-- Dependencies: 220
-- Data for Name: subjects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subjects (id, name, semester, teacher_id, teacher) FROM stdin;
2	Веб-разработка	1	2	Петров Петр Петрович
5	Менеджмент	3	3	\N
3	Дизайн интерфейсов	2	6	Антон Сергеевич
8	Теория вероятностей	4	5	\N
4	Экономика	2	9	\N
1	Программирование на Python	1	6	Иванов Иван Иванович
7	Алгоритмы и структуры данных	4	2	\N
6	Базы данных	3	7	\N
\.


--
-- TOC entry 4876 (class 0 OID 25382)
-- Dependencies: 228
-- Data for Name: teachers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.teachers (id, name, created_at) FROM stdin;
1	Иванов Иван Иванович	2025-03-21 21:40:24.649971
2	Петров Петр Петрович	2025-03-21 21:40:24.649971
3	Сидорова Мария Сергеевна	2025-03-21 21:40:24.649971
4	Иванов Иван Иванович	2025-03-21 22:08:21.284404
5	Петров Петр Петрович	2025-03-21 22:08:21.284404
6	Сидорова Мария Сергеевна	2025-03-21 22:08:21.284404
7	Иванов Иван Иванович	2025-03-21 22:11:08.129883
8	Петров Петр Петрович	2025-03-21 22:11:08.129883
9	Сидорова Мария Сергеевна	2025-03-21 22:11:08.129883
\.


--
-- TOC entry 4880 (class 0 OID 25423)
-- Dependencies: 232
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (userid, name, email, password, registrationdate, lastlogin, role, username, created_at, updated_at, first_name, last_name, patronymic, snils, inn, passport) FROM stdin;
6	Admin User	admin@example.com	$2b$10$rxPpy4R/O3ySXnmPoBQwSuOYzJfrDOoHgypgyacUa4n4B9Szsikly	2025-03-22 05:55:42.348843	\N	admin	admin	2025-03-22 05:55:42.348843	2025-03-22 05:55:42.348843	\N	\N	\N	\N	\N	\N
\.


--
-- TOC entry 4895 (class 0 OID 0)
-- Dependencies: 221
-- Name: grades_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.grades_id_seq', 19, true);


--
-- TOC entry 4896 (class 0 OID 0)
-- Dependencies: 225
-- Name: news_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.news_id_seq', 25, true);


--
-- TOC entry 4897 (class 0 OID 0)
-- Dependencies: 229
-- Name: reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reports_id_seq', 1, false);


--
-- TOC entry 4898 (class 0 OID 0)
-- Dependencies: 223
-- Name: scholarships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.scholarships_id_seq', 8, true);


--
-- TOC entry 4899 (class 0 OID 0)
-- Dependencies: 217
-- Name: students_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.students_id_seq', 9, true);


--
-- TOC entry 4900 (class 0 OID 0)
-- Dependencies: 219
-- Name: subjects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.subjects_id_seq', 10, true);


--
-- TOC entry 4901 (class 0 OID 0)
-- Dependencies: 227
-- Name: teachers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.teachers_id_seq', 9, true);


--
-- TOC entry 4902 (class 0 OID 0)
-- Dependencies: 231
-- Name: users_userid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_userid_seq', 6, true);


--
-- TOC entry 4696 (class 2606 OID 16458)
-- Name: grades grades_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_pkey PRIMARY KEY (id);


--
-- TOC entry 4703 (class 2606 OID 24594)
-- Name: news news_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.news
    ADD CONSTRAINT news_pkey PRIMARY KEY (id);


--
-- TOC entry 4707 (class 2606 OID 25404)
-- Name: reports reports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_pkey PRIMARY KEY (id);


--
-- TOC entry 4701 (class 2606 OID 16477)
-- Name: scholarships scholarships_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scholarships
    ADD CONSTRAINT scholarships_pkey PRIMARY KEY (id);


--
-- TOC entry 4692 (class 2606 OID 16444)
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- TOC entry 4694 (class 2606 OID 16451)
-- Name: subjects subjects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT subjects_pkey PRIMARY KEY (id);


--
-- TOC entry 4705 (class 2606 OID 25388)
-- Name: teachers teachers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teachers
    ADD CONSTRAINT teachers_pkey PRIMARY KEY (id);


--
-- TOC entry 4709 (class 2606 OID 25434)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 4711 (class 2606 OID 25432)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (userid);


--
-- TOC entry 4713 (class 2606 OID 25538)
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- TOC entry 4699 (class 1259 OID 16483)
-- Name: idx_scholarship_student; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scholarship_student ON public.scholarships USING btree (student_id);


--
-- TOC entry 4697 (class 1259 OID 16485)
-- Name: idx_student; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_student ON public.grades USING btree (student_id);


--
-- TOC entry 4698 (class 1259 OID 16484)
-- Name: idx_subject; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_subject ON public.grades USING btree (subject_id);


--
-- TOC entry 4714 (class 2606 OID 25389)
-- Name: subjects fk_teacher; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT fk_teacher FOREIGN KEY (teacher_id) REFERENCES public.teachers(id);


--
-- TOC entry 4715 (class 2606 OID 16459)
-- Name: grades grades_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id);


--
-- TOC entry 4716 (class 2606 OID 16464)
-- Name: grades grades_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.subjects(id);


--
-- TOC entry 4718 (class 2606 OID 25405)
-- Name: reports reports_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- TOC entry 4719 (class 2606 OID 25410)
-- Name: reports reports_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.subjects(id) ON DELETE CASCADE;


--
-- TOC entry 4717 (class 2606 OID 16478)
-- Name: scholarships scholarships_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scholarships
    ADD CONSTRAINT scholarships_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id);


-- Completed on 2025-04-22 05:49:40

--
-- PostgreSQL database dump complete
--

-- Completed on 2025-04-22 05:49:40

--
-- PostgreSQL database cluster dump complete
--

