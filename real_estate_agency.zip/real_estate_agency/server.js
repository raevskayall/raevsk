const express = require('express');
const { Pool } = require('pg');
const bodyParser = require('body-parser');
const cors = require('cors');
const session = require('express-session');
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const bcrypt = require('bcrypt');
const path = require('path');
require('dotenv').config();

const saltRounds = 10;
const app = express();
const PORT = process.env.PORT || 3000;

// Конфигурация подключения к PostgreSQL
const pool = new Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_NAME,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT,
});

// Middleware
app.use(cors({
    origin: process.env.CLIENT_URL,
    credentials: true
}));
app.use(bodyParser.json());
app.use(express.static('public'));

// Конфигурация сессии
app.use(session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: { 
        secure: process.env.NODE_ENV === 'production',
        maxAge: 24 * 60 * 60 * 1000,
        sameSite: 'lax'
    }
}));

// Инициализация Passport
app.use(passport.initialize());
app.use(passport.session());

// Стратегия аутентификации
passport.use(new LocalStrategy(async (username, password, done) => {
    try {
        const userResult = await pool.query(
            'SELECT * FROM users WHERE username = $1', 
            [username]
        );
        
        if (userResult.rows.length === 0) {
            return done(null, false, { message: 'Неверные учетные данные' });
        }

        const user = userResult.rows[0];
        const isValid = await bcrypt.compare(password, user.password);
        
        return isValid 
            ? done(null, user) 
            : done(null, false, { message: 'Неверные учетные данные' });
    } catch (err) {
        return done(err);
    }
}));

// Сериализация пользователя
passport.serializeUser((user, done) => done(null, user.id));
passport.deserializeUser(async (id, done) => {
    try {
        const user = await pool.query('SELECT * FROM users WHERE id = $1', [id]);
        done(null, user.rows[0]);
    } catch (err) {
        done(err);
    }
});

// Middleware для проверки аутентификации
const ensureAuth = (req, res, next) => {
    req.isAuthenticated() ? next() : res.status(401).json({ error: 'Не авторизован' });
};

// Middleware для проверки роли администратора
const ensureAdmin = (req, res, next) => {
    req.user?.role === 'admin' ? next() : res.status(403).json({ error: 'Доступ запрещен' });
};

// Валидация полей пользователя
const validateUserFields = (req, res, next) => {
    const { username, password } = req.body;
    if (!username || !password) {
        return res.status(400).json({ error: 'Все поля обязательны для заполнения' });
    }
    next();
};

// Регистрация пользователя
app.post('/register', validateUserFields, async (req, res) => {
    try {
        const { username, password, role = 'user' } = req.body;
        
        if (role === 'admin' && !req.user?.isAdmin) {
            return res.status(403).json({ error: 'Недостаточно прав' });
        }

        const existingUser = await pool.query(
            'SELECT * FROM users WHERE username = $1', 
            [username]
        );

        if (existingUser.rows.length > 0) {
            return res.status(400).json({ error: 'Пользователь уже существует' });
        }

        const hash = await bcrypt.hash(password, saltRounds);
        const result = await pool.query(
            'INSERT INTO users (username, password, role) VALUES ($1, $2, $3) RETURNING id',
            [username, hash, role]
        );
        
        res.status(201).json({ id: result.rows[0].id });
    } catch (err) {
        res.status(500).json({ error: 'Ошибка регистрации' });
    }
});

// Аутентификация
app.post('/login', (req, res, next) => {
    passport.authenticate('local', (err, user, info) => {
        if (err) return next(err);
        if (!user) return res.status(401).json({ error: 'Неверные учетные данные' });
        
        req.logIn(user, (err) => {
            if (err) return next(err);
            return res.json({ 
                id: user.id,
                username: user.username,
                role: user.role
            });
        });
    })(req, res, next);
});

// Выход
app.post('/logout', (req, res) => {
    req.logout(() => res.sendStatus(200));
});

// Профиль пользователя
app.get('/api/profile', ensureAuth, (req, res) => {
    res.json({ 
        username: req.user.username, 
        role: req.user.role,
        created_at: req.user.created_at
    });
});

// ==================== КЛИЕНТЫ ====================
const validateClientFields = (req, res, next) => {
    const { first_name, last_name, phone } = req.body;
    if (!first_name || !last_name || !phone) {
        return res.status(400).json({ error: 'Обязательные поля: имя, фамилия, телефон' });
    }
    next();
};

app.get('/clients', ensureAuth, async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM clients');
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: 'Ошибка получения клиентов' });
    }
});

app.post('/clients', ensureAuth, validateClientFields, async (req, res) => {
    try {
        const { first_name, last_name, phone, email } = req.body;
        const result = await pool.query(
            `INSERT INTO clients 
            (first_name, last_name, phone, email) 
            VALUES ($1, $2, $3, $4) 
            RETURNING *`,
            [first_name, last_name, phone, email]
        );
        res.status(201).json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: 'Ошибка создания клиента' });
    }
});

app.put('/clients/:client_id', ensureAuth, ensureAdmin, async (req, res) => {
    try {
        const { first_name, last_name, phone, email } = req.body;
        const result = await pool.query(
            `UPDATE clients SET 
            first_name = $1, 
            last_name = $2, 
            phone = $3, 
            email = $4 
            WHERE client_id = $5 
            RETURNING *`,
            [first_name, last_name, phone, email, req.params.client_id]
        );
        
        result.rows[0] 
            ? res.json(result.rows[0]) 
            : res.status(404).json({ error: 'Клиент не найден' });
    } catch (err) {
        res.status(500).json({ error: 'Ошибка обновления' });
    }
});

app.delete('/clients/:client_id', ensureAuth, ensureAdmin, async (req, res) => {
    try {
        const result = await pool.query(
            'DELETE FROM clients WHERE client_id = $1',
            [req.params.client_id]
        );
        result.rowCount > 0 
            ? res.sendStatus(204) 
            : res.status(404).json({ error: 'Клиент не найден' });
    } catch (err) {
        res.status(500).json({ error: 'Ошибка удаления' });
    }
});

// ==================== РИЭЛТОРЫ ====================
const validateRealtorFields = (req, res, next) => {
    const { first_name, last_name, phone, hire_date } = req.body;
    if (!first_name || !last_name || !phone || !hire_date) {
        return res.status(400).json({ error: 'Заполните все обязательные поля' });
    }
    next();
};

// Получение списка всех риэлторов (НОВЫЙ ЭНДПОИНТ)
app.get('/realtors', ensureAuth, async (req, res) => {
    try {
        const { page = 1, limit = 10 } = req.query;
        const offset = (page - 1) * limit;
        
        const result = await pool.query(`
            SELECT *, 
                   COUNT(*) OVER() AS total_count,
                   CONCAT(first_name, ' ', last_name) AS full_name 
            FROM realtors 
            ORDER BY realtor_id 
            LIMIT $1 OFFSET $2
        `, [limit, offset]);
        
        res.json({
            data: result.rows,
            total: result.rows[0]?.total_count || 0,
            page: parseInt(page),
            limit: parseInt(limit)
        });
    } catch (err) {
        res.status(500).json({ error: 'Ошибка получения списка риэлторов' });
    }
});

// Получение конкретного риэлтора
app.get('/realtors/:realtor_id', ensureAuth, async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT *, 
                    CONCAT(first_name, ' ', last_name) AS full_name 
             FROM realtors 
             WHERE realtor_id = $1`,
            [req.params.realtor_id]
        );
        
        result.rows[0] 
            ? res.json(result.rows[0]) 
            : res.status(404).json({ error: 'Риэлтор не найден' });
    } catch (err) {
        res.status(500).json({ error: 'Ошибка получения данных' });
    }
});

// Создание риэлтора
app.post('/realtors', ensureAuth, ensureAdmin, validateRealtorFields, async (req, res) => {
    try {
        const { first_name, last_name, phone, email, hire_date } = req.body;
        const result = await pool.query(
            `INSERT INTO realtors 
            (first_name, last_name, phone, email, hire_date) 
            VALUES ($1, $2, $3, $4, $5) 
            RETURNING *,
                   CONCAT(first_name, ' ', last_name) AS full_name`,
            [first_name, last_name, phone, email, hire_date]
        );
        res.status(201).json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ 
            error: 'Ошибка создания риэлтора',
            details: err.message 
        });
    }
});

// Обновление риэлтора
app.put('/realtors/:realtor_id', ensureAuth, ensureAdmin, async (req, res) => {
    try {
        const { first_name, last_name, phone, email, hire_date } = req.body;
        const result = await pool.query(
            `UPDATE realtors SET 
            first_name = $1, 
            last_name = $2, 
            phone = $3, 
            email = $4, 
            hire_date = $5 
            WHERE realtor_id = $6 
            RETURNING *,
                   CONCAT(first_name, ' ', last_name) AS full_name`,
            [first_name, last_name, phone, email, hire_date, req.params.realtor_id]
        );
        
        result.rows[0] 
            ? res.json(result.rows[0]) 
            : res.status(404).json({ error: 'Риэлтор не найден' });
    } catch (err) {
        res.status(500).json({ 
            error: 'Ошибка обновления',
            details: err.message 
        });
    }
});

// Удаление риэлтора
app.delete('/realtors/:realtor_id', ensureAuth, ensureAdmin, async (req, res) => {
    try {
        const result = await pool.query(
            `DELETE FROM realtors 
             WHERE realtor_id = $1 
             RETURNING realtor_id`,
            [req.params.realtor_id]
        );
        
        result.rowCount > 0 
            ? res.json({ 
                success: true,
                deletedId: result.rows[0].realtor_id 
              }) 
            : res.status(404).json({ error: 'Риэлтор не найден' });
    } catch (err) {
        res.status(500).json({ 
            error: 'Ошибка удаления',
            details: err.message 
        });
    }
});

// ==================== НЕДВИЖИМОСТЬ ====================
const validatePropertyFields = (req, res, next) => {
    const { address, price, property_type, realtor_id } = req.body;
    if (!address || !price || !property_type || !realtor_id) {
        return res.status(400).json({ error: 'Заполните обязательные поля' });
    }
    next();
};

app.get('/properties', ensureAuth, async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT p.*, r.first_name || ' ' || r.last_name as realtor_name 
            FROM properties p
            JOIN realtors r ON p.realtor_id = r.realtor_id
        `);
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: 'Ошибка получения объектов' });
    }
});

app.post('/properties', ensureAuth, validatePropertyFields, async (req, res) => {
    try {
        const { address, price, property_type, size, realtor_id, description } = req.body;
        const result = await pool.query(
            `INSERT INTO properties 
            (address, price, property_type, size, realtor_id, description) 
            VALUES ($1, $2, $3, $4, $5, $6) 
            RETURNING *`,
            [address, price, property_type, size, realtor_id, description]
        );
        res.status(201).json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: 'Ошибка создания объекта' });
    }
});

app.put('/properties/:property_id', ensureAuth, async (req, res) => {
    try {
        const { address, price, property_type, size, realtor_id, description } = req.body;
        const result = await pool.query(
            `UPDATE properties SET 
            address = $1, 
            price = $2, 
            property_type = $3, 
            size = $4, 
            realtor_id = $5, 
            description = $6 
            WHERE property_id = $7 
            RETURNING *`,
            [address, price, property_type, size, realtor_id, description, req.params.property_id]
        );
        
        result.rows[0] 
            ? res.json(result.rows[0]) 
            : res.status(404).json({ error: 'Объект не найден' });
    } catch (err) {
        res.status(500).json({ error: 'Ошибка обновления' });
    }
});

app.delete('/properties/:property_id', ensureAuth, ensureAdmin, async (req, res) => {
    try {
        const result = await pool.query(
            'DELETE FROM properties WHERE property_id = $1',
            [req.params.property_id]
        );
        result.rowCount > 0 
            ? res.sendStatus(204) 
            : res.status(404).json({ error: 'Объект не найден' });
    } catch (err) {
        res.status(500).json({ error: 'Ошибка удаления' });
    }
});

// ==================== СДЕЛКИ ====================
const validateTransactionFields = (req, res, next) => {
    const { client_id, property_id, realtor_id, date, amount } = req.body;
    if (!client_id || !property_id || !realtor_id || !date || !amount) {
        return res.status(400).json({ error: 'Все поля обязательны' });
    }
    next();
};

app.get('/transactions/:transaction_id', ensureAuth, async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT t.*, 
            c.first_name || ' ' || c.last_name as client_name,
            p.address as property_address,
            r.first_name || ' ' || r.last_name as realtor_name
            FROM transactions t
            JOIN clients c ON t.client_id = c.client_id
            JOIN properties p ON t.property_id = p.property_id
            JOIN realtors r ON t.realtor_id = r.realtor_id
            WHERE transaction_id = $1`,
            [req.params.transaction_id]
        );
        result.rows[0] 
            ? res.json(result.rows[0]) 
            : res.status(404).json({ error: 'Сделка не найдена' });
    } catch (err) {
        res.status(500).json({ error: 'Ошибка получения данных' });
    }
});

app.post('/transactions', ensureAuth, validateTransactionFields, async (req, res) => {
    try {
        const { client_id, property_id, realtor_id, date, amount } = req.body;
        const result = await pool.query(
            `INSERT INTO transactions 
            (client_id, property_id, realtor_id, date, amount) 
            VALUES ($1, $2, $3, $4, $5) 
            RETURNING *`,
            [client_id, property_id, realtor_id, date, amount]
        );
        res.status(201).json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: 'Ошибка создания сделки' });
    }
});

app.put('/transactions/:transaction_id', ensureAuth, async (req, res) => {
    try {
        const { client_id, property_id, realtor_id, date, amount } = req.body;
        const result = await pool.query(
            `UPDATE transactions SET 
            client_id = $1, 
            property_id = $2, 
            realtor_id = $3, 
            date = $4, 
            amount = $5 
            WHERE transaction_id = $6 
            RETURNING *`,
            [client_id, property_id, realtor_id, date, amount, req.params.transaction_id]
        );
        
        result.rows[0] 
            ? res.json(result.rows[0]) 
            : res.status(404).json({ error: 'Сделка не найдена' });
    } catch (err) {
        res.status(500).json({ error: 'Ошибка обновления' });
    }
});

app.delete('/transactions/:transaction_id', ensureAuth, ensureAdmin, async (req, res) => {
    try {
        const result = await pool.query(
            'DELETE FROM transactions WHERE transaction_id = $1',
            [req.params.transaction_id]
        );
        result.rowCount > 0 
            ? res.sendStatus(204) 
            : res.status(404).json({ error: 'Сделка не найдена' });
    } catch (err) {
        res.status(500).json({ error: 'Ошибка удаления' });
    }
});

// Статистика активности
app.get('/api/activity', ensureAuth, async (req, res) => {
    try {
        const activities = await pool.query(`
            (SELECT 'client' as type, first_name || ' ' || last_name as message, created_at 
            FROM clients ORDER BY created_at DESC LIMIT 3)
            UNION ALL
            (SELECT 'property', address, created_at 
            FROM properties ORDER BY created_at DESC LIMIT 3)
            UNION ALL
            (SELECT 'transaction', 'Сумма: ' || amount::text, date 
            FROM transactions ORDER BY date DESC LIMIT 3)
            ORDER BY created_at DESC LIMIT 5
        `);
        
        res.json(activities.rows.map(row => ({
            type: row.type,
            message: `${row.type === 'client' ? 'Новый клиент: ' : 
                     row.type === 'property' ? 'Новый объект: ' : 'Новая сделка: '}${row.message}`,
            date: row.created_at || row.date
        })));
    } catch (err) {
        res.status(500).json({ error: 'Ошибка получения активности' });
    }
});

// Обработка 404
app.use((req, res) => {
    res.status(404).json({ error: 'Страница не найдена' });
});

// Обработка ошибок
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: 'Внутренняя ошибка сервера' });
});

// Запуск сервера
app.listen(PORT, () => {
    console.log(`Сервер запущен на порту ${PORT}`);
});