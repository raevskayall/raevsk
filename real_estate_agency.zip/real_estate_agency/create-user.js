const { Pool } = require('pg');
const bcrypt = require('bcrypt');
const readline = require('readline');
require('dotenv').config();

const saltRounds = 10;

// Настройка подключения к БД
const pool = new Pool({
  user: process.env.DB_USER || 'postgres',
  host: process.env.DB_HOST || 'localhost',
  database: process.env.DB_NAME || 'real_estate_agency',
  password: process.env.DB_PASSWORD || '22081921',
  port: process.env.DB_PORT || 5432,
});

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

async function createUser() {
  try {
    // Запрос данных пользователя
    const username = await question('Введите имя пользователя: ');
    const password = await hiddenQuestion('Введите пароль: ');
    const role = await question('Введите роль (admin/user): ');

    // Хеширование пароля
    const hashedPassword = await bcrypt.hash(password, saltRounds);

    // Вставка в БД
    const result = await pool.query(
      'INSERT INTO users (username, password, role) VALUES ($1, $2, $3) RETURNING id',
      [username, hashedPassword, role]
    );

    console.log(`\nПользователь создан с ID: ${result.rows[0].id}`);

  } catch (error) {
    console.error('\nОшибка создания пользователя:', error.message);
  } finally {
    pool.end();
    rl.close();
  }
}

// Вспомогательные функции для ввода
function question(query) {
  return new Promise(resolve => rl.question(query, resolve));
}

function hiddenQuestion(query) {
  return new Promise(resolve => {
    const stdin = process.openStdin();
    process.stdin.on('data', char => {
      if (char === '\r' || char === '\n') {
        process.stdin.pause();
      } else {
        process.stdout.write('*');
      }
    });
    
    rl.question(query, password => {
      resolve(password);
    });
  });
}

// Запуск скрипта
createUser();